# Copyright 2016 Splunk Inc. All rights reserved.

# Python Standard Libraries
import logging
import socket
# Third-Party Libraries
import pytest
# Custom Libraries
from splunk_appinspect.splunk_http_event_collector import http_event_collector


class SplunkEventCollectorHandler(logging.Handler):

    def __init__(self, splunk_host, event_collector_token, http_event_port='8088', http_event_server_ssl=True):
        logging.Handler.__init__(self)
        self.host = splunk_host
        self.token = event_collector_token
        self.http_event_port = http_event_port
        self.http_event_server_ssl = http_event_server_ssl

    def emit(self, record):
        event_collector = http_event_collector(self.token,
                                               self.host,
                                               http_event_port=self.http_event_port,
                                               http_event_server_ssl=self.http_event_server_ssl)

        splunkevt = {}

        if hasattr(record, 'msg'):
            splunkevt.update({"msg": record.msg})

        if hasattr(record, 'message'):
            splunkevt.update({"message": record.message})

        if hasattr(record, 'levelname'):
            splunkevt.update({"level": record.levelname})

        if hasattr(record, 'process'):
            splunkevt.update({"process": record.process})

        if hasattr(record, 'processName'):
            splunkevt.update({"processName": record.processName})

        if hasattr(record, 'lineno'):
            splunkevt.update({"lineno": record.lineno})

        if hasattr(record, 'module'):
            splunkevt.update({"module": record.module})

        if hasattr(record, 'filename'):
            splunkevt.update({"module": record.filename})

        payload = {}
        payload.update({"event": splunkevt})
        payload.update({"host": socket.gethostname()})

        event_collector.sendEvent(payload)
