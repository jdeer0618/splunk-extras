# Copyright 2016 Splunk Inc. All rights reserved.

# Python Standard Libraries
import os
import logging
# Custom Libraries
import file_resource
import rest_map_configuration_file
import splunk_appinspect


logger = logging.getLogger(__name__)


class RestHandler:
    """ Represents a rest handler. """

    def __init__(self, name, handler_file_name="", handler_module="", handler_module_file_name="", handler_actions="", hander_type=""):
        self.name = name
        self.handler_file_name = handler_file_name
        self.handler_module = handler_module
        self.handler_module_file_name = handler_module_file_name
        self.handler_actions = handler_actions
        self.handler_type = hander_type

    def handler_file(self):
        """Represents the file for a specific file

        See http://docs.splunk.com/Documentation/Splunk/latest/Admin/restmapconf

        handlerfile=<unique filename>
        * Script to execute.
        * For bin/myAwesomeAppHandler.py, specify only myAwesomeAppHandler.py.
        """
        return file_resource.FileResource(self.handler_file_name)

    def handler(self):
        """Represents the file for a module in a file file

        See http://docs.splunk.com/Documentation/Splunk/latest/Admin/restmapconf

        # handler=<SCRIPT>.<CLASSNAME>
        # * The name and class name of the file to execute.
        # * The file *must* live in an application's bin subdirectory.
        # * For example, $SPLUNK_HOME/etc/apps/<APPNAME>/bin/TestHandler.py has a class
        #   called MyHandler (which, in the case of python must be derived from a base
        #   class called 'splunk.rest.BaseRestHandler'). The tag/value pair for this is:
        #   "handler=TestHandler.MyHandler".

        """
        return file_resource.FileResource(self.handler_module_file_name)


class RestMap:
    """ Represents a restmap.conf file. """

    def __init__(self, app):
        self.app = app
        self.restmap_conf_file_path = self.app.get_filename('default',
                                                            'restmap.conf')

    def configuration_file_exists(self):
        return self.app.file_exists('default', 'restmap.conf')

    def get_configuration_file(self):
        return self.app.get_config('restmap.conf',
                                   config_file=rest_map_configuration_file.RestMapConfigurationFile())

    def global_handler_file(self):
        """
        The global handler that has a default specifed.

        See http://docs.splunk.com/Documentation/Splunk/latest/Admin/restmapconf
        """
        for section in self.get_configuration_file().section_names():
            if section == "global":
                for key, value in self.get_configuration_file().items(section):
                    if key.lower() == "pythonHandlerPath":
                        file_path = os.path.join(
                            self.app.app_dir, "bin/", value)
                        return file_resource.FileResource(file_path)

        file_path = os.path.join(self.app.app_dir, "bin/", "rest_handler.py")
        return file_resource.FileResource(file_path)

    def handlers(self):
        handler_list = []

        for section in self.get_configuration_file().section_names():

            # Only check sections that are "script" or "admin_external"
            if "script" in section or "admin_external" in section:

                handler = RestHandler(section, self.app.app_dir)

                for key, value in self.get_configuration_file().items(section):

                    # From spec file
                    # script=<path to a script executable>
                    # * For scripttype=python this is optional.  It allows you to run a script
                    #   which is *not* derived from 'splunk.rest.BaseRestHandler'.  This is
                    # rarely used.  Do not use this unless you know what you
                    # are doing.

                    if "script" in section and key.lower() == "script":
                        handler.handler_file_name = os.path.join(
                            self.app.app_dir, "bin/", value)

                    if "script" in section and key.lower() == "handler":
                        handler.handler_file_name = os.path.join(
                            self.app.app_dir, "bin/", value)

                        # TODO: Guard against bad conf (e.g. handler=blah instead of
                        # handler=blah.mod)
                        path = value.split(".")[:1][0] + ".py"

                        handler.handler_module_file_name = os.path.join(
                            self.app.app_dir, "bin/", path)
                        handler.handler_module = value

                    if "admin_external" in section and key.lower() == "handlerfile":
                        handler.handler_file_name = os.path.join(
                            self.app.app_dir, "bin/", value)

                    if "admin_external" in section and key.lower() == "handlertype":
                        handler.handler_type = value

                handler_list.append(handler)

        return handler_list
