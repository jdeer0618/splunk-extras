# Copyright 2016 Splunk Inc. All rights reserved.

"""This file is used to track the version of Splunk AppInspect."""

__version__ = "1.4.1.88"
