# Copyright 2016 Splunk Inc. All rights reserved.

"""
AppPackageHandler class handles app package input which is passed to CLI.
This class currently can handle these cases:
- Single tar/zip app package
- Single app package folder
And one layer deep of these multiple packages:
- Folder of multiple tar/zip app packages
- Folder of multiple app package folders
- Tar/zip folder of multiple app package folders
- tar/zip folder of multiple tar/zip app packages

usage:
apps = []
apps = AppPackageHandler(package_location).apps
"""

# Standard Python Libraries
import os
from zipfile import ZipFile
import logging
import tempfile
import tarfile
import shutil
import re
# Third-Party Libraries
# N/A
# Custom Libraries

logger = logging.getLogger(__name__)


class AppPackageHandler():

    def __init__(self, app_package):
        self.apps = {}  # Dictionary of (app's folder name, app's path)
        self.app_packages = []  # Array of all packages object
        origin_package = AppPackage.factory(app_package)
        
        if origin_package.is_app:
            # Found app in the root dir, this is a single app
            self._add_package(origin_package)
            logger.info("Found app in {}".format(origin_package.origin_path))
            return

        app_found = False
        for bit in os.listdir(origin_package.working_path):
            bit_path = os.path.join(origin_package.working_path, bit)
            bit_package = AppPackage.factory(bit_path)
            if bit_package.is_app:
                app_found = True
                self._add_package(bit_package)
                logger.info("Found app in {}".format(bit_package.origin_path))

        if not app_found:
            logger.error("No app(s) found. Apps must contain an `app.conf`"
                        " file in the `default` directory and app folders must"
                        " not start with the `.` character.")

    def _add_package(self, package):
        """
        :param package: AppPackage object
        """
        working_path = package.working_path
        self.apps[os.path.basename(working_path)] = working_path
        self.app_packages.append(package)

    def cleanup(self):
        """
        Clean up all working temp dirs
        """
        for package in self.app_packages:
            package.clean_up()


class AppPackage(object):

    NOT_ALLOWED_PATTERN = re.compile(
        r"""
            (?P<nix>
                ^\.         # Hidden folder
            )
            | (?P<macosx>
                ^__MACOSX   # Mac OSX folder
            )
        """,
        re.VERBOSE
    )

    def __init__(self, app_package):
        self.origin_path = app_package
        self.working_path = None
        self.is_app = False
        self.validate_app()

    @staticmethod
    def factory(app_package=""):
        if os.path.isdir(app_package):
            return FolderAppPackage(app_package)
        else:
            return TarAppPackage(app_package)

    def is_splunk_app(self, dir):
        """
        A folder is an app if it has default/app.conf
        """
        if not os.path.isdir(dir):
            return False
        app_conf_path = os.path.join(dir, "default", "app.conf")
        return os.path.isfile(app_conf_path)

    def validate_app(self):
        pass

    def does_contain_prohibited_folder(self, dir):
        found_pattern = False
        for d in os.listdir(dir):
            matches = re.findall(self.NOT_ALLOWED_PATTERN, d)
            if len(matches) > 0:
                logger.warning(
                    "Found directory pattern is prohibited in the top level of an folder: {} in {}".format(d, dir))
                found_pattern = True
        return found_pattern

    def clean_up(self):
        pass


class FolderAppPackage(AppPackage):

    def __init__(self, app_package):
        super(FolderAppPackage, self).__init__(app_package)

    def validate_app(self):
        self.working_path = self.origin_path
        self.does_contain_prohibited_folder(self.origin_path)
        if os.path.basename(self.origin_path).startswith("."):
            # Ignore hidden folder
            self.is_app = False
            return
        self.is_app = self.is_splunk_app(self.origin_path)


class TarAppPackage(AppPackage):

    def __init__(self, app_package):
        super(TarAppPackage, self).__init__(app_package)

    def verify_traversal_attack(self, tar_name, target_dir, tar_list):
        for d in tar_list:
            if not os.path.abspath(os.path.join(target_dir, d)).startswith(target_dir):
                logger.info(
                    "Invalid tar file {}. Possibly directory traversal attack at {}".format(tar_name, d))
                return False
        return True

    def validate_app(self):
        # Ignore hidden files
        if os.path.basename(self.origin_path).startswith("."):
            self.is_app = False
            return

        temp_dir = tempfile.mkdtemp()
        self.working_path = temp_dir
        try:
            if self.origin_path.endswith('.zip'):
                with ZipFile(self.origin_path) as zip:
                    if self.verify_traversal_attack(self.origin_path, temp_dir, zip.namelist()):
                        zip.extractall(temp_dir)
            else:
                with tarfile.open(name=self.origin_path) as tar:
                    if self.verify_traversal_attack(self.origin_path, temp_dir, tar.getnames()):
                        tar.extractall(path=temp_dir)
        except:
            logger.warning(
                "Failed to extract {}".format(os.path.basename(self.origin_path)))
            self.is_app = False
            return

        self.does_contain_prohibited_folder(self.working_path)

        # If user packs app by tar -cvzf app-folder.tgz app-folder, it's extracted in <temp-dir>/app-folder
        # If user packs app by tar -cvzf app-folder.tgz default bin metadata..., it's extracted in <temp-dor>
        # Checking app pattern for one layer deeper
        if len(os.listdir(self.working_path)) == 1:
            # Folder has only one sub-folder
            self.working_path = os.path.join(
                self.working_path, os.listdir(self.working_path)[0])

        self.is_app = self.is_splunk_app(self.working_path)

    def clean_up(self):
        if self.working_path and os.path.isdir(self.working_path):
            logger.info("Cleaning temp directory: {}".format(
                self.working_path))
            shutil.rmtree(self.working_path)
