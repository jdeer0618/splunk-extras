# Copyright 2016 Splunk Inc. All rights reserved.

"""This is the core validation logic used to centralize validation run-time.

This module contains functions to accumulate and run checks under configurations
as needed.
"""

# Python Standard Libraries
import logging
from datetime import datetime
# Third-Party Libraries
import concurrent.futures
from futures_then import ThenableFuture
# Custom Libraries
import splunk_appinspect


logger = logging.getLogger(__name__)


def _emit(eventname, listeners, *args):
    for listener in listeners:
        listener.handle_event(eventname, *args)


def validate_packages(app_package_handler,
                      args=None,
                      groups_to_validate=None,
                      listeners=None,
                      resource_manager=None):
    """Returns a ValidationSummary object

    :param args (Dict) - A dictionary of values that will be used to modify
        check selection, check run-time, and check execution.
    :param check_dirs (List of Strings) - An array of string paths pointing to
        where groups can be found
    :param app_package_handler (AppPackageHandler Object) - An AppPackageHandler
        that contains AppPackage objects to be used for validation.
    :param resource_manager A ResourceManager object used to help facilitate
        dependency injection for checks
    """
    if args is None:
        args = {}
    if groups_to_validate is None:
        groups_to_validate = []
    if listeners is None:
        listeners = []
    if resource_manager is None:
        resource_manager = splunk_appinspect.resource_manager.ResourceManager()

    appinspect_version = splunk_appinspect.version.__version__
    logger.info("Executing checks using Splunk AppInspect version {}".format(appinspect_version))
    args["appinspect_version"] = appinspect_version

    app_names = app_package_handler.apps.keys()

    validation_report = splunk_appinspect.validation_report.ValidationReport()
    validation_report.validation_start()

    _emit('start_validation', listeners, app_names)

    try:
        apps = map(lambda x: splunk_appinspect.App(x), app_package_handler.apps.values())
        splunk_args = {}

        if 'splunk_version' in args:
            splunk_args['splunk_version'] = args['splunk_version']

        splunk_args['apps'] = apps
        with resource_manager.context(splunk_args) as instances:
            for app in apps:
                application_validation_report = splunk_appinspect.validation_report.ApplicationValidationReport(app,
                                                                                                                args)
                application_validation_report.validation_start()
                _emit('start_app', listeners, app)
                results = _run_checks(app,
                                      args=args,
                                      groups_to_validate=groups_to_validate,
                                      listeners=listeners,
                                      resource_manager_context=instances)
                application_validation_report.results = results
                application_validation_report.validation_completed()

                _emit('finish_app', listeners, app, application_validation_report)
                validation_report.add_application_validation_report(application_validation_report)

        validation_report.validation_completed()
        _emit('finish_validation', listeners, app_names, validation_report)

    except Exception as exception:
        validation_report.validation_error(exception)
        logger.exception(exception)
    finally:
        try:
            app_package_handler.cleanup()
            for app in apps:
                app.cleanup()
        except exception:
            validation_report.validation_error(exception)
            logger.exception(exception)

        return validation_report


def _run_checks(app,
                groups_to_validate,
                args=None,
                resource_manager_context=None,
                listeners=None):
    """Returns a list of tuples containing a Group object, a Check object, and a
    Reporter object.

    (group_object, check_object, reporter_object)

    :param app (App Object) - An App object that represents the Splunk App
        object
    :param args (Dict) - A dictionary of values that will be used to modify
        check selection, check run-time, and check execution.
    :param: groups_to_validate - TODO
    :param check_dirs (List of Strings) - An array of string paths pointing to
        where groups can be found
    :param resource_manager_context
    :param listeners (List of Listeners) - A list of Listener objects used to detect validation events
        as a splunk application validation is executed
    """
    if args is None:
        args = {}
    if listeners is None:
        listeners = []
    if resource_manager_context is None:
        resource_manager_context = {}

    futures = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as threadpool:
        ready_for_deferred = ThenableFuture()

        def dispatch_check(check):
            def run_check():
                check_start = datetime.now()
                _emit('start_check', listeners, check)
                reporter = check.run(app, resource_manager_context)
                check_end = datetime.now()
                reporter.metrics = {
                    'start_time': check_start,
                    'end_time': check_end,
                    'execution': (check_end - check_start).total_seconds()
                }
                _emit('finish_check', listeners, check, reporter)
                return reporter

            if check.deferred:
                return ready_for_deferred.then(lambda _: threadpool.submit(run_check))
            else:
                return threadpool.submit(run_check)

        logger.debug("Beginning validation execution.")
        for group in groups_to_validate:
            logger.debug(("Executing start_group event for"
                          " Group: {}"
                          " Group_Checks: {}"
                          " Listeners: {}"
                          ).format(group,
                                   list(group.checks()),
                                   listeners))

            _emit('start_group', listeners, group, group.checks())
            # This runs the initial checks
            future_checks = map(lambda check: (check, dispatch_check(check)),
                                group.checks())
            # This accumulates the deferred checks
            futures.append((group, future_checks))

            logger.debug(("Executing finish_group event for"
                          " Group: {}"
                          " Group_Checks: {}"
                          " Listeners: {}"
                          ).format(group,
                                   list(group.checks()),
                                   listeners))
            _emit('finish_group', listeners, group, group.checks())

        # This allows the deferred checks to be run
        ready_for_deferred.set_result(True)

    # After exiting 'with', all checks are run.
    # future.result() calls a promise that returns the reporter
    return_values = [(group_object, check_object, future.result())
                     for group_object, checks
                     in futures
                     for check_object, future
                     in checks]
    return return_values
