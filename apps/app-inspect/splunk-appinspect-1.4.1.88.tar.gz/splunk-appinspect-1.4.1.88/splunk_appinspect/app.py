# Copyright 2016 Splunk Inc. All rights reserved.

# Python Standard Libraries
import hashlib
import logging
import os
import re
import stat
import subprocess
import tarfile
import traceback
import StringIO
# Custom Libraries
import alert_actions
import app_configuration_file
import app_package_handler
import authentication_configuration_file
import authorize_configuration_file
import custom_commands
import custom_visualizations
import configuration_file
import configuration_parser
import file_resource
import indexes_configuration_file
import inputs_configuration_file
import inputs_specification_file
import inspected_file
import modular_inputs
import props_configuration_file
import rest_map
import saved_searches
import transforms_configuration_file
import web_configuration_file
import workflow_actions

logger = logging.getLogger(__name__)


class App():
    """
    This class manages the unpacking of apps to a temp directory, and encapsulates
    common functionality such as iterating through files and searching through
    files with regular expressions.
    """

    def __init__(self, location):
        """
        :param location Either a package(.spl, .tgz, or .zip) or a directory containing the app
        """
        self.package = None
        self.package_handler = None
        if os.path.isdir(location):
            self.app_dir = os.path.abspath(location)
            self.name = os.path.split(location)[1]
        else:
            self.package_handler = app_package_handler.AppPackageHandler(
                location)

            # Highlander principle
            self.name = self.package_handler.apps.keys()[0]
            self.app_dir = self.package_handler.apps.values()[0]

        self.LINUX_ARCH = "linux"
        self.WIN_ARCH = "win"
        self.DARWIN_ARCH = "darwin"
        self.DEFAULT_ARCH = "default"
        self.arch_bin_dirs = {
            self.LINUX_ARCH: [os.path.join(self.app_dir, "linux_x86", "bin"),
                              os.path.join(self.app_dir, "linux_x86_64", "bin")],
            self.WIN_ARCH: [os.path.join(self.app_dir, "windows_x86", "bin"),
                            os.path.join(self.app_dir, "windows_x86_64", "bin")],
            self.DARWIN_ARCH: [os.path.join(self.app_dir, "darwin_x86", "bin"),
                               os.path.join(self.app_dir, "darwin_x86_64", "bin")],
            self.DEFAULT_ARCH: [os.path.join(self.app_dir, "bin")]
        }

    def targlob(self):
        """
        Create an in-memory tarball of all files in the directory
        """
        glob = StringIO.StringIO()
        tar = tarfile.open(mode='w', fileobj=glob)
        tar.add(self.app_dir, recursive=True, arcname=self.name)
        tar.close()
        return glob.getvalue()

    def __del__(self):
        self.cleanup()

    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        """Clean up our temporary directory"""
        self.cleanup()

    def cleanup(self):
        if self.package_handler is not None:
            self.package_handler.cleanup()

    def get_config(self, name, dir='default', config_file=None):
        """Returns a parsed config file as a ConfFile object. Note that this 
        does not do any of Splunk's layering- this is just the config file, 
        parsed into a dictionary that is accessed via the ConfFile's helper 
        functions.

        :param name The name of the config file.  For example, 'inputs.conf'
        :param dir The directory in which to look for the config file.  By default, 'default'
        """
        app_filepath = self.get_filename(dir, name)

        log_output = ("'{}' called '{}' to retrieve the configuration file '{}'"
                      " at directory '{}'. App filepath: {}").format(__file__,
                                                                     "get_config",
                                                                     name,
                                                                     dir,
                                                                     app_filepath)
        logger.debug(log_output)
        if not self.file_exists(app_filepath):
            error_output = ("No such conf file: {}").format(app_filepath)
            raise IOError(error_output)

        # Makes generic configuration file if no specified configuration file is
        # passed in
        if config_file is None:
            config_file = configuration_file.ConfigurationFile()

        with open(app_filepath) as file:
            config_file = configuration_parser.parse(file,
                                                     config_file,
                                                     configuration_parser.configuration_lexer)

        return config_file

    def get_spec(self, name, dir='default', config_file=None):
        """Returns a parsed config spec file as a ConfFile object.  

        :param name The name of the config file.  For example, 'inputs.conf.spec'
        :param dir The directory in which to look for the config file.  By default, 'default'
        """
        app_filepath = self.get_filename(dir, name)

        log_output = ("'{}' called '{}' to retrieve the configuration file '{}'"
                      " at directory '{}'. App filepath: {}").format(__file__,
                                                                     "get_config",
                                                                     name,
                                                                     dir,
                                                                     app_filepath)
        logger.debug(log_output)
        if not self.file_exists(app_filepath):
            error_output = ("No such conf file: {}").format(app_filepath)
            raise IOError(error_output)

        # Makes generic configuration file if no specified configuration file is
        # passed in
        if config_file is None:
            config_file = configuration_file.ConfigurationFile()

        with open(app_filepath) as file:
            config_file = configuration_parser.parse(
                file, config_file, configuration_parser.specification_lexer)

        return config_file

    def get_meta(self, name, directory='metadata', meta_file=None):
        """Returns a parsed meta file as a Meta object.  

        :param name The name of the meta file.  For example, 'default.meta'
        :param directory The directory in which to look for the config file.
            By default, 'default'
        """
        # This uses the configuration file conventions because there does not
        # appear to be any difference between configuration files and meta
        # files.
        # TODO: investigate if meta file class should exist
        app_filepath = self.get_filename(directory, name)

        log_output = ("'{}' called '{}' to retrieve the configuration file '{}'"
                      " at directory '{}'. App filepath: {}").format(__file__,
                                                                     "get_config",
                                                                     name,
                                                                     directory,
                                                                     app_filepath)
        logger.debug(log_output)
        if not self.file_exists(app_filepath):
            error_output = ("No such metadata file: {}").format(app_filepath)
            raise IOError(error_output)

        # Makes generic meta file if no specified meta file is
        # passed in
        if meta_file is None:
            meta_file = configuration_file.ConfigurationFile()

        with open(app_filepath) as file:
            meta_file = configuration_parser.parse(file,
                                                   meta_file,
                                                   configuration_parser.configuration_lexer)

        return meta_file

    def get_raw_conf(self, name, dir='default'):
        """
        Returns a raw version of the config file.
        :param name: The name of the config file.  For example 'inputs.conf'
        :param dir The directory in which to look for the config file.  By default, 'default'
        :return: A raw representation of the conf file
        """
        # Should this be a with fh.open??
        app_filepath = self.get_filename(dir, name)
        fh = open(app_filepath, 'rb')
        conf_content = fh.read()
        fh.close()

        log_output = ("'{}' called '{}' to retrieve the configuration file '{}'"
                      " at directory '{}'. App filepath: {}").format(__file__,
                                                                     "get_raw_conf",
                                                                     name,
                                                                     dir,
                                                                     app_filepath)
        logger.debug(log_output)

        return conf_content

    def get_filename(self, *path_parts):
        """
        Given a relative path, return a fully qualified location to that file
        in a format suitable for passing to open, etc.

        example: app.get_filename('default', 'inputs.conf')
        """
        return os.path.join(self.app_dir, *path_parts)

    def app_info(self):
        """
        Get app version, hash, title, description, author for the app header
        """
        try:
            app_info = {}
            app_config = self.get_config("app.conf")
            if not('launcher') in app_config.section_names():
                raise Exception("No launcher section in app.conf")
            app_info['author'] = (app_config.get('launcher', 'author')
                                  if app_config.has_option('launcher', 'author')
                                  else 'MISSING')
            app_info['description'] = (app_config.get('launcher', 'description')
                                       if app_config.has_option('launcher',
                                                                'description')
                                       else 'MISSING')
            app_info['version'] = (app_config.get('launcher', 'version')
                                   if app_config.has_option('launcher',
                                                            'version')
                                   else 'MISSING')
            app_info['name'] = (app_config.get('ui', 'label')
                                if app_config.has_option('ui', 'label')
                                else 'MISSING')
            app_info['hash'] = self._get_hash()
            return app_info
        except Exception as e:
            msg = repr(e)
            traceback.print_exc(e)
            raise Exception(
                "Unable to gather app data- check app.conf. (" + msg + ")")

    def _get_hash(self):
        md5 = hashlib.md5()
        for dir, file, ext in self.iterate_files(excluded_types=['.pyc', '.pyo']):
            file = open(os.path.join(self.app_dir, dir, file))
            md5.update(file.read())
        return md5.hexdigest()

    def iterate_files(self, basedir='', excluded_dirs=[], types=[], excluded_types=[], recurse_depth=float("inf")):
        """Iterates through each of the files in the app, optionally filtered
        by file extension.

        Example:

        for file in app.iterate_files(types=['.gif', '.jpg']):
            pass

        This should be considered to only be a top down traversal/iteration. 
        This is because the filtering of directories, and logic used to track
        depth are based on the os.walk functionality using the argument of 
        `topdown=True` as a default value. If bottom up traversal is desired 
        then a separate function will need to be created.

        :param basedir The directory to start in
        :param excluded_dirs These are directories to exclude when iterating. 
            Exclusion is done by directory name matching only. This means if you
            exclude the directory 'examples' it would exclude both `examples/`
            and `default/examples`, as well as any path containing a directory
            called `examples`.
        :param types An array of types that the filename should match
        :param excluded_types An array of file extensions that should be
            skipped.
        :param recurse_depth This is used to indicate how deep you want 
            traversal to go. 0 means do no recurse, but return the files at the 
            directory specified.
        """
        check_extensions = len(types) > 0
        root_path = os.path.join(self.app_dir, basedir, "")
        root_depth = root_path.count(os.path.sep)

        for base, directories, files in os.walk(root_path):
            # Adds a trailing '/' or '\'. This is needed to help determine the
            # depth otherwise the calculation is off by one
            base = os.path.join(base, "")
            current_iteration_depth = base.count(os.path.sep)
            current_depth = current_iteration_depth - root_depth

            # Filters undesired directories
            directories[:] = [directory
                              for directory
                              in directories
                              if directory not in excluded_dirs]

            # Create the file's relative path from within the app
            dir_in_app = base.replace(self.app_dir + os.path.sep, '')
            if current_depth <= recurse_depth:
                for file in files:
                    filebase, ext = os.path.splitext(file)
                    if((check_extensions and ext not in types) or
                            ext in excluded_types):
                        next
                    else:
                        yield (dir_in_app, file, ext)
            else:
                next

    def get_filepaths_of_files(self, basedir="", excluded_dirs=[], filenames=[], types=[], excluded_types=[]):
        for directory, file, ext in self.iterate_files(basedir=basedir,
                                                       excluded_dirs=excluded_dirs,
                                                       types=types,
                                                       excluded_types=[]):
            current_file_full_path = os.path.join(self.app_dir,
                                                  directory,
                                                  file)
            current_file_relative_path = os.path.join(directory, file)
            split_filename = os.path.splitext(file)
            filename = split_filename[0]
            check_filenames = len(filenames) > 0

            filename_is_in_filenames = not(filename in filenames)
            if(check_filenames and filename_is_in_filenames):
                next
            else:
                yield (current_file_relative_path, current_file_full_path)

    def file_exists(self, *path_parts):
        """Check for the existence of a file given the relative path.
        Returns True/False

        Example:
        if app.file_exists('default', 'transforms.conf'):
             print "File exists! Validate that~!~"
        """
        file_path = os.path.join(self.app_dir, *path_parts)
        does_file_exist = os.path.isfile(file_path)

        log_output = ("'{}.{}' was called. File path being checked:'{}'."
                      " Does File Exist:{}").format(__file__,
                                                    "file_exists",
                                                    file_path,
                                                    does_file_exist)
        logger.debug(log_output)
        return does_file_exist

    def directory_exists(self, *path_parts):
        """Check for the existence of a directory given the relative path.
        Returns True/False

        Example:
        if app.file_exists('local'):
             print "Distributed apps shouldn't have a 'local' directory"
        """
        directory_path = os.path.join(self.app_dir, *path_parts)
        does_file_exist = os.path.isdir(directory_path)

        log_output = ("'{}.{} was called.'. Directory path being checked:'{}'."
                      " Does Directory Exist:{}").format(__file__,
                                                         "directory_exists",
                                                         directory_path,
                                                         does_file_exist)
        logger.debug(log_output)
        return does_file_exist

    def some_files_exist(self, files):
        """ Takes an array of relative filenames and returns true if any file
        listed exists.
        """
        for file in files:
            if self.file_exists(file):
                return True
        return False

    def some_directories_exist(self, directories):
        """ Takes an array of relative paths and returns true if any file
        listed exists.
        """
        for directory in directories:
            if self.directory_exists(directory):
                return True
        return False

    def all_files_exist(self, files):
        """ Takes an array of relative filenames and returns true if all
        listed files exist.
        """
        for file in files:
            if not(self.file_exists(file)):
                return False
        return True

    def all_directories_exist(self, directories):
        """ Takes an array of relative paths and returns true if all listed 
        directories exists.
        """
        for directory in directories:
            if not(self.directory_exists(directory)):
                return False
        return True

    def search_for_patterns(self, patterns, basedir='', excluded_dirs=[], types=[], excluded_types=[]):
        """ Takes a list of patterns and iterates through all files, running 
        each of the patterns on each line of each of those files.

        Returns a list of tuples- the first element is the file (with line 
        number), the second is the match from the regular expression.
        """
        matches = []
        all_excluded_types = ['.pyc', '.pyo']
        all_excluded_types.extend(excluded_types)  # never search these files

        files_iterator = self.iterate_files(basedir=basedir,
                                            excluded_dirs=excluded_dirs,
                                            types=types,
                                            excluded_types=all_excluded_types)
        for dir, filename, ext in files_iterator:
            relative_filepath = os.path.join(dir, filename)
            file_to_inspect = inspected_file.InspectedFile.factory(os.path.join(self.app_dir,
                                                                                dir,
                                                                                filename))
            found_matches = file_to_inspect.search_for_patterns(patterns)
            matches_with_relative_path = []
            for (fileref_output, file_match) in found_matches:
                filepath, line_number = fileref_output.rsplit(":", 1)
                relative_file_ref_output = "{}:{}".format(relative_filepath,
                                                          line_number)
                matches_with_relative_path.append((relative_file_ref_output,
                                                   file_match))
            matches.extend(matches_with_relative_path)

        return matches

    def search_for_pattern(self, pattern, basedir='', excluded_dirs=[], types=[], excluded_types=[]):
        """ Takes a pattern and iterates over matching files, testing each line.
        Same as search_for_patterns, but with a single pattern.
        """
        return self.search_for_patterns([pattern],
                                        basedir=basedir,
                                        excluded_dirs=excluded_dirs,
                                        types=types,
                                        excluded_types=excluded_types)

    def is_executable(self, filename):
        """ Checks to see if any of the executable bits are set on a file
        """
        st = os.stat(os.path.join(self.app_dir, filename))
        return bool(st.st_mode & (stat.S_IXOTH | stat.S_IXUSR | stat.S_IXGRP))

    def is_text(self, filename):
        """Checks to see if the file is a text type via the 'file' command"""
        file_path = self.get_filename(filename)
        cmd = "file {} -L".format(file_path)
        try:
            output = subprocess.check_output(cmd, shell=True)
            return True if re.search(r':.* text', output) else False
        except Exception as e:
            # TODO: Self log error here.  Issues with hidden folders
            return False

    #---------------------------------
    # "Domain" Objects
    #---------------------------------
    def get_alert_actions(self):
        return alert_actions.AlertActions(self)

    def get_custom_commands(self):
        return custom_commands.CustomCommands(self)

    def get_custom_visualizations(self):
        return custom_visualizations.CustomVisualizations(self)

    def get_modular_inputs(self):
        return modular_inputs.ModularInputs(self)

    def get_rest_map(self):
        return rest_map.RestMap(self)

    def get_saved_searches(self):
        return saved_searches.SavedSearches(self)

    def get_workflow_actions(self):
        return workflow_actions.WorkFlowActions(self)

    #---------------------------------
    # ConfFile Helper Definitions
    #---------------------------------
    def app_conf(self):
        return self.get_config('app.conf',
                               config_file=app_configuration_file.AppConfigurationFile())

    def authentication_conf(self):
        return self.get_config('authentication.conf',
                               config_file=authentication_configuration_file.AuthenticationConfigurationFile())

    def authorize_conf(self):
        return self.get_config('authorize.conf',
                               config_file=authorize_configuration_file.AuthorizeConfigurationFile())

    def indexes_conf(self):
        return self.get_config('indexes.conf',
                               config_file=indexes_configuration_file.IndexesConfigurationFile())

    def inputs_conf(self):
        return self.get_config('inputs.conf',
                               config_file=inputs_configuration_file.InputsConfigurationFile())

    def props_conf(self):
        return self.get_config('props.conf',
                               config_file=props_configuration_file.PropsConfigurationFile())

    def transforms_conf(self):
        return self.get_config('transforms.conf',
                               config_file=transforms_configuration_file.TransformsConfigurationFile())

    def web_conf(self):
        return self.get_config('web.conf',
                               config_file=web_configuration_file.WebConfigurationFile())

    #---------------------------------
    # SpecFile Helper Definitions
    #---------------------------------
    def get_inputs_specification(self):
        return inputs_specification_file.InputsSpecification()

    #---------------------------------
    # File Resource Helper Definitions
    #---------------------------------
    def app_icon(self):
        return file_resource.FileResource(os.path.join(self.app_dir, 'appserver/static/appIcon.png'))

    def setup_xml(self):
        return file_resource.FileResource(os.path.join(self.app_dir, 'default/setup.xml'))
