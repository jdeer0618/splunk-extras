# Copyright 2016 Splunk Inc. All rights reserved.


class ValidationReportFormatter(object):

    def __init__(self):
        pass

    def format(self, validation_report):
        pass
