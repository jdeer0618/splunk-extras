# Copyright 2016 Splunk Inc. All rights reserved.

"""
### Custom Visualizations Support Checks

[Custom Visualizations](https://docs.splunk.com/Documentation/Splunk/latest/AdvancedDev/CustomVizApiRef) are defined in `default/visualizations.conf`.
"""

# Python Standard Library
import logging
import os
# Third-Party Support
# N/A
# Custom
# N/A
import splunk_appinspect

logger = logging.getLogger(__name__)


@splunk_appinspect.tags("splunk_appinspect", "custom_visualizations")
@splunk_appinspect.cert_version(min="1.1.18")
def check_for_visualizations_directory(app, reporter):
    """Check that custom visualizations have an
    `appserver/static/visualizations/` directory.
    """
    if app.file_exists("default", "visualizations.conf"):
        custom_visualizations_component = app.get_custom_visualizations()
        if custom_visualizations_component.does_visualizations_directory_exist():
            pass  # Success, Directory exists
        else:
            reporter_output = ("The `{}`"
                               " directory does not exist."
                               ).format(custom_visualizations_component.visualizations_directory)
            reporter.fail(reporter_output)
    else:
        reporter_output = "visualizations.conf does not exist."
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "developer_guidance", "custom_visualizations")
@splunk_appinspect.cert_version(min="1.1.18")
def check_that_visualizations_conf_has_matching_default_meta_stanza(app, reporter):
    """Check that each stanza in `default/vizualizations.conf` has a matching
    stanza in metadata/default.meta`.
    """
    if app.file_exists("default", "visualizations.conf"):
        custom_visualizations = app.get_custom_visualizations()
        if app.file_exists("metadata", "default.meta"):
            default_meta = app.get_meta("default.meta")

            visualizations_conf_stanza_names = [custom_visualization.name
                                                for custom_visualization
                                                in custom_visualizations.get_custom_visualizations()]
            default_meta_stanza_names = [stanza_name
                                         for stanza_name
                                         in default_meta.section_names()]

            for visualizations_conf_stanza_name in visualizations_conf_stanza_names:
                expected_default_meta_stanza_name = ("visualizations/{}"
                                                     ).format(visualizations_conf_stanza_name)
                if expected_default_meta_stanza_name not in default_meta_stanza_names:
                    reporter_output = ("No [{}] stanza found in default.meta"
                                       ).format(expected_default_meta_stanza_name)
                    reporter.warn(reporter_output)
        else:
            stanza_names = [custom_visualization.name
                            for custom_visualization
                            in custom_visualizations.get_custom_visualizations()]
            for stanza_name in stanza_names:
                reporter_output = ("visualizatsions.conf was detected, but no"
                                   " default.meta file was detected. Please add"
                                   " a default.meta file with the stanza [{}]"
                                   " declared and the desired permissions set."
                                   ).format(stanza_names)
                reporter.warn(reporter_output)
    else:
        reporter_output = "visualizations.conf does not exist."
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "custom_visualizations")
@splunk_appinspect.cert_version(min="1.1.20")
def check_for_matching_stanza_visualization_directory(app, reporter):
    """Check that each custom visualization stanza in
    `default/visualizations.conf` has a matching directory in the
    `appserver/static/visualizations/` directory.
    """
    if app.file_exists("default", "visualizations.conf"):
        custom_visualizations = app.get_custom_visualizations()
        if custom_visualizations.does_visualizations_directory_exist():
            visualizations_without_directory = [custom_visualization
                                                for custom_visualization
                                                in custom_visualizations.get_custom_visualizations()
                                                if not app.directory_exists(custom_visualizations.visualizations_directory,
                                                                            custom_visualization.name)]
            for visualization_without_directory in visualizations_without_directory:
                missing_directory = os.path.join(custom_visualizations.visualizations_directory,
                                                 visualization_without_directory.name)
                reporter_output = ("The stanza [{}] is missing its corresponding"
                                   " directory at `{}`. Please add the"
                                   " visualization directory and its corresponding"
                                   " files."
                                   ).format(visualization_without_directory.name,
                                            missing_directory)
                reporter.fail(reporter_output)
        else:
            reporter_output = ("The `{}`"
                               " directory does not exist."
                               ).format(custom_visualizations.visualizations_directory)
            reporter.fail(reporter_output)
    else:
        reporter_output = "visualizations.conf does not exist."
        reporter.not_applicable(reporter_output)
