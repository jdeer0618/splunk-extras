# Copyright 2016 Splunk Inc. All rights reserved.

"""
### Security vulnerabilities
"""

# Python Standard Libraries
import logging
# Custom Libraries
import splunk_appinspect


logger = logging.getLogger(__name__)
report_display_order = 5

potentially_dangerous_windows_filetypes = ['.cmd', '.ps1', '.bat', '.ps2',
                                           '.ws', '.wsf', '.psc1', '.psc2']


@splunk_appinspect.tags('splunk_appinspect', 'security')
@splunk_appinspect.cert_version(min='1.1.0')
def check_for_pexpect(app, reporter):
    """Check for use of `pexpect` to ensure it is only controlling app 
    processes.
    """
    for match in app.search_for_pattern('pexpect.run', types=['.py']):
        reporter_output = ("Possible use of pexpect- detected in {}."
                           ).format(match[0])
        reporter.manual_check(reporter_output)


@splunk_appinspect.tags('splunk_appinspect', 'security', 'cloud')
@splunk_appinspect.cert_version(min='1.1.0')
def check_for_secret_disclosure(app, reporter):
    """Check for passwords and secrets."""
    for match in app.search_for_pattern('(login|passwd|password|community|privpass)\s*=\s*[^\s]+'):
        reporter.manual_check(
            "Possible secret disclosure in {}: {}".format(match[0], match[1].group()))


@splunk_appinspect.tags('splunk_appinspect', 'security')
@splunk_appinspect.cert_version(min='1.1.0')
def check_for_vbs_command_injection(app, reporter):
    """Check for command injection in VBS files."""
    for match in app.search_for_pattern('Shell.*Exec', types=['.vbs']):
        reporter.manual_check(
            "Possible command injection in {}: {}".format(match[0], match[1].group()))


@splunk_appinspect.tags('splunk_appinspect', 'security')
@splunk_appinspect.cert_version(min='1.1.0')
def check_for_command_injection_through_env_vars(app, reporter):
    """Check for command injection through environment variables."""
    for match in app.search_for_pattern('start.*%', types=potentially_dangerous_windows_filetypes):
        reporter.manual_check(
            "Possible command injection in {}: {}".format(match[0], match[1].group()))


@splunk_appinspect.tags('splunk_appinspect', 'security', 'cloud')
@splunk_appinspect.cert_version(min='1.1.0')
def check_for_insecure_http_calls_in_python(app, reporter):
    """Check for insecure HTTP calls in Python."""
    insecure_http_patterns = ["HTTPConnection", "socket", "urllib*"]
    matches = app.search_for_patterns(insecure_http_patterns, types=[".py"])
    for (fileref_output, match) in matches:
        filepath, line_number = fileref_output.rsplit(":", 1)
        reporter_output = ("Possible insecure HTTP Connection."
                           " Match: {}"
                           " File: {}"
                           " Line Number: {}"
                           ).format(match.group(), filepath, line_number)
        reporter.manual_check(reporter_output)


@splunk_appinspect.tags('splunk_appinspect', 'security')
@splunk_appinspect.cert_version(min='1.1.0')
def check_for_stacktrace_returned_to_user(app, reporter):
    """Check that stack traces are not being returned to an end user."""
    for match in app.search_for_pattern('format_exc', types=['.py']):
        reporter_output = ("Stacktrace being formatted in {}: {}"
                           ).format(match[0], match[1].group())
        reporter.manual_check(reporter_output)


@splunk_appinspect.tags('splunk_appinspect', 'security')
@splunk_appinspect.cert_version(min='1.1.0')
def check_for_environment_variable_use_in_python(app, reporter):
    """Check for the use of environment variables."""
    for match in app.search_for_pattern('os\.environ', types=['.py']):
        reporter_output = ("Environment variable being used in {}: {}"
                           ).format(match[0], match[1].group())
        reporter.manual_check(reporter_output)
