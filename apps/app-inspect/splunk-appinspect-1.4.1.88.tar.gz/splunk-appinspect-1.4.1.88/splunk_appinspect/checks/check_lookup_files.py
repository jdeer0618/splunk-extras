# Copyright 2016 Splunk Inc. All rights reserved.

"""
### Lookup file standards

Lookups add fields from an external source to events based on the values of 
fields that are already present in those events.
"""

# Python Standard Library
import logging
import os
import re
import sys
import csv
# Third-Party Libraries
# N/A
# Custom Libraries
import splunk_appinspect

logger = logging.getLogger(__name__)
report_display_order = 13


@splunk_appinspect.tags('splunk_appinspect')
@splunk_appinspect.cert_version(min='1.1.18')
def check_lookup_csv_has_rows(app, reporter):
    """Check that `.csv` files have a least one row."""

    for basedir, file, ext in app.iterate_files(basedir="lookups", types=[".csv"]):
        current_file_relative_path = os.path.join(basedir, file)
        current_file_full_path = app.get_filename(current_file_relative_path)

        try:
            with open(current_file_full_path, "rb") as csvfile:
                reader = csv.reader(csvfile, delimiter=",")
                data = list(reader)
                row_count = len(data)

                if row_count == 0 or len(data) == 0:
                    output = "The lookup csv {} does not contain any rows and should be removed.".format(file)
                    reporter.fail(output)
        except Exception:
            reporter.manual_check("Check that the lookup CSV {} has at least one row.".format(file))