# Copyright 2016 Splunk Inc. All rights reserved.

"""
### Custom workflow actions structure and standards

[Custom workflow actions](https://docs.splunk.com/Documentation/Splunk/latest/Knowledge/Aboutlookupsandfieldactions)
are defined in
[workflow_actions.conf](https://docs.splunk.com/Documentation/Splunk/latest/Admin/Workflow_actionsconf)
located at `default/workflow_actions.conf`.
"""

# Python Standard Library
import logging
import re
# Custom Modules
import splunk_appinspect

logger = logging.getLogger(__name__)

report_display_order = 20


@splunk_appinspect.tags('splunk_appinspect', 'custom_workflow_actions')
@splunk_appinspect.cert_version(min='1.1.7')
def check_command_conf_exists(app, reporter):
    """Check that a valid `workflow_actions.conf` file exists at
    `default/workflow_actions.conf`.
    """
    workflow_actions = app.get_workflow_actions()
    if workflow_actions.configuration_file_exists():
        pass
    else:
        reporter_output = ("The 'workflow_actions.conf' does not exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags('splunk_appinspect', 'custom_workflow_actions')
@splunk_appinspect.cert_version(min='1.1.7')
def check_required_stanza_fields_are_specified(app, reporter):
    """Check that stanzas in `workflow_actions.conf.spec` have the required
    fields, type, and label.
    """
    workflow_actions = app.get_workflow_actions()
    if workflow_actions.configuration_file_exists():
        for action in workflow_actions.get_workflow_actions():

            if "type" not in action.args:
                reporter_output = ("The stanza [{}] does not specify 'type'."
                                   ).format(action.name)
                reporter.fail(reporter_output)

            if "label" not in action.args:
                reporter_output = ("The stanza [{}] does not specify 'label'."
                                   ).format(action.name)
                reporter.fail(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.20")
def check_workflow_actions_link_uri_does_not_use_http_protocol(app, reporter):
    """Check that for each workflow action in `workflow_actions.conf` the
    link.uri property does not use the http protocol.
    """
    if app.file_exists("default", "workflow_actions.conf"):
        workflow_actions = app.get_workflow_actions()

        workflow_actions_with_link_uri = [workflow_action
                                          for workflow_action
                                          in workflow_actions.get_workflow_actions()
                                          if "link.uri" in workflow_action.args]
        workflow_actions_with_http_link_uri = [workflow_action
                                               for workflow_action
                                               in workflow_actions_with_link_uri
                                               for link
                                               in workflow_action.args["link.uri"]
                                               if re.search("^http://", link)]

        for workflow_action in workflow_actions_with_http_link_uri:
            reporter_output = ("The workflow action [{}] link.uri property uses"
                               " the http:// protocol. Please change it to use"
                               " https://"
                               ).format(workflow_action.name)
            reporter.fail(reporter_output)
    else:
        reporter_output = ("`workflow_actions.conf` does not exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.20")
def check_workflow_actions_for_unexpected_link_uri(app, reporter):
    """Check that for each workflow action in `workflow_actions.conf` the
    link.uri property starts with https.
    """
    if app.file_exists("default", "workflow_actions.conf"):
        workflow_actions = app.get_workflow_actions()

        workflow_actions_with_link_uri = [workflow_action
                                          for workflow_action
                                          in workflow_actions.get_workflow_actions()
                                          if "link.uri" in workflow_action.args]
        unanticipated_workflow_actions = [workflow_action
                                          for workflow_action
                                          in workflow_actions_with_link_uri
                                          for link
                                          in workflow_action.args["link.uri"]
                                          if re.search("^https?://", link) is None]

        for workflow_action in unanticipated_workflow_actions:
            reporter_output = ("The workflow action [{}] does not specify"
                               " the https:// protocol."
                               ).format(workflow_action.name)
            reporter.manual_check(reporter_output)
    else:
        reporter_output = ("`workflow_actions.conf` does not exist.")
        reporter.not_applicable(reporter_output)
