# Copyright 2016 Splunk Inc. All rights reserved.

"""
### Data model files and configurations

[Data models](https://docs.splunk.com/Documentation/Splunk/latest/Knowledge/Aboutdatamodels)
are configured via a [datamodels.conf](https://docs.splunk.com/Documentation/Splunk/latest/Admin/Datamodelsconf)
located at `default/datamodels.conf`.
"""

# Python Standard Libraries
import collections
import logging
import os
# Third-Party Libraries
# N/A
# Custom Libraries
import splunk_appinspect


report_display_order = 25
logger = logging.getLogger(__name__)


@splunk_appinspect.tags("splunk_appinspect")
@splunk_appinspect.cert_version(min="1.0.0")
@splunk_appinspect.display(report_display_order=1)
def check_validate_data_models_conf_file_in_correct_locations(app, reporter):
    """Check that when using data models the `datamodels.conf` file only exists
    in the default directory.
    """
    # Gathers all datamodels.conf files
    datamodels_filepath = os.path.join("default", "datamodels.conf")

    for relative_filepath, full_filepath in app.get_filepaths_of_files(filenames=["datamodels"], types=[".conf"]):
        if relative_filepath != datamodels_filepath:
            reporter_output = ("A datamodels.conf file"
                               " was found outside of the default directory."
                               " File: {}").format(relative_filepath)
            reporter.fail(reporter_output)


@splunk_appinspect.tags("splunk_appinspect")
@splunk_appinspect.cert_version(min="1.1.0")
def check_validate_no_missing_json_data(app, reporter):
    """Check that each stanza in 
    [datamodels.conf](https://docs.splunk.com/Documentation/Splunk/latest/Admin/Datamodelsconf)
    has a matching JSON file in `default/data/models/`.
    """
    data_model_location = "default/data/models"
    for relative_filepath, full_filepath in app.get_filepaths_of_files(filenames=["datamodels"], types=[".conf"]):
        config = app.get_config('datamodels.conf')

        for section in config.section_names():
            json_filename = "{}.json".format(section)
            does_matching_json_file_exist = app.file_exists(data_model_location,
                                                            json_filename)
            if not does_matching_json_file_exist:
                reporter_output = ("There is no corresponding JSON file for [{}] in file: {}"
                                   ).format(section,
                                            relative_filepath)
                reporter.fail(reporter_output)
