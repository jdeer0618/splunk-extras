# Copyright 2016 Splunk Inc. All rights reserved.

"""
### Python file standards
"""

# Python Standard Library
import logging
import os
# Third-Party
# N/A
# Custom Modules
import splunk_appinspect

logger = logging.getLogger(__name__)

report_display_order = 40


@splunk_appinspect.tags('cloud')
@splunk_appinspect.cert_version(min='1.1.22')
def check_for_python_files(app, reporter):
    """Check if the app contains python scripts."""
    application_files = list(app.iterate_files(types=[".py"]))
    if application_files:
        for directory, file, ext in application_files:
            current_file_relative_path = os.path.join(directory, file)
            reporter_output = ("python script found."
                               " File: {}").format(current_file_relative_path)
            reporter.manual_check(reporter_output)

    else:
        reporter_output = "No python scripts found in app."
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags('splunk_appinspect', 'cloud')
@splunk_appinspect.cert_version(min='1.0.0')
def check_for_compiled_python(app, reporter):
    """Check that there are no `.pyc` or `.pyo` files included in the app."""
    for dir, file, ext in app.iterate_files(types=['.pyc', '.pyo']):
        current_file_relative_path = os.path.join(dir, file)
        reporter_output = ("A Compiled Python file was detected. File: {}"
                           ).format(current_file_relative_path)
        reporter.fail(reporter_output)


@splunk_appinspect.tags('splunk_appinspect', 'security', 'cloud')
@splunk_appinspect.cert_version(min='1.1.8')
def check_for_questionable_commands(app, reporter):
    """Check for the use of `subprocess` and OS command calls in Python.

For example:

* `subprocess.call`
* `exec`
    """
    questionable_statements_regex = ["import\s+(?:.*,)?\s*os(?!\w+)",
                                     "from\s+os(?!\w+)",
                                     "import\s+(?:.*,)?\s*commands(?!\w+)",
                                     "from\s+commands(?!\w+)",
                                     "import\s+(?:.*,)?\s*subprocess(?!\w+)",
                                     "from\s+subprocess(?!\w+)",
                                     "subprocess\s*.\s*check_output",
                                     "subprocess\s*.\s*call",
                                     "subprocess\s*.\s*check_call",
                                     "subprocess\s*.\s*Popen",
                                     "import\s+(?:.*,)?\s*distutils\s*.\s*util(?!\w+)",
                                     "import\s+(?:.*,)?\s*distutils\s*.\s*file_util(?!\w+)",
                                     "import\s+(?:.*,)?\s*distutils\s*.\s*dir_util(?!\w+)",
                                     "from\s+distutils\s+import\s+(?:.*,)?\s*util(?!\w+)",
                                     "from\s+distutils\s+import\s+(?:.*,)?\s*file_util(?!\w+)",
                                     "from\s+distutils\s+import\s+(?:.*,)?\s*dir_util(?!\w+)",
                                     "distutils\s*.\s*util\s*.\s*execute",
                                     "exec\s*\(.*\)?",
                                     "os\s*.\s*exec",
                                     "os\s*.\s*kill",
                                     "os\s*.\s*popen",
                                     "os\s*.\s*remove",
                                     "os\s*.\s*rename",
                                     "os\s*.\s*rmdir",
                                     "os\s*.\s*startfile",
                                     "os\s*.\s*system",
                                     "os\s*.\s*unlink",
                                     "shutil\s*.\s*rmtree",
                                     "shutil\s*.\s*move"]
    matches = list(app.search_for_patterns(questionable_statements_regex,
                                           types=['.py']))
    python_files = list(app.iterate_files(types=['.py']))

    if python_files:
        for (fileref_output, match) in matches:
            filename, line_number = fileref_output.rsplit(":", 1)
            reporter_output = ("The following line will be inspected during code review."
                               " Match: {}"
                               " File: {}"
                               " Line Number: {}"
                               ).format(match.group(), filename, line_number)
            reporter.manual_check(reporter_output)
    else:
        reporter_output = ("No python files found.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min='1.1.17')
def check_for_possible_threading(app, reporter):
    """Check for the use of threading, and multiprocesses. Threading must be
    used with discretion and not negatively affect the Splunk installation as a
    whole.
    """
    questionable_statements_regex = ["from\s+os\s+import\s+(?:.*,)?\s*fork(?!\w+)",
                                     "from\s+os\s+import\s+(?:.*,)?\s*forkpty(?!\w+)",
                                     "os\s*.\s*fork",
                                     "from\s+os\s+import\s+(?:.*,)?\s*spawn",
                                     "os\s*.\s*spawn",
                                     "from\s+os\s+import\s+(?:.*,)?\s*setsid(?!\w+)",
                                     "os\s*.\s*setsid",
                                     "from\s+distutils\s+import\s+(?:.*,)?\s*spawn(?!\w+)",
                                     "distutils\s*.\s*spawn"]
    matches = app.search_for_patterns(questionable_statements_regex,
                                      types=['.py'])
    python_files = list(app.iterate_files(types=['.py']))

    if python_files:
        for (fileref_output, match) in matches:
            filename, line_number = fileref_output.rsplit(":", 1)
            reporter_output = ("The following line will be inspected during code review."
                               " Match: {}"
                               " File: {}"
                               " Line Number: {}"
                               ).format(match.group(), filename, line_number)
            reporter.manual_check(reporter_output)
    else:
        reporter_output = ("No python files found.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags('splunk_appinspect', 'cloud')
@splunk_appinspect.cert_version(min='1.1.16')
def check_for_mismatch_compile_files(app, reporter):
    """Check that any compiled files (.pyo, .pyc) have a matching
    source file (.py).
    """

    py_filenames = [(directory, file, ext)
                    for (directory, file, ext)
                    in app.iterate_files(types=['.py'])]
    pyc_filenames = [(directory, file, ext)
                     for (directory, file, ext)
                     in app.iterate_files(types=['.pyc'])]
    pyo_filenames = [(directory, file, ext)
                     for (directory, file, ext)
                     in app.iterate_files(types=['.pyo'])]

    def locate_unmatched_files(target_files, search_files):
        unmatched_target_files = []
        for (target_directory, target_file, target_ext) in target_files:
            target_filename = os.path.splitext(file)[0]
            found_matching_source_file = False
            for (source_directory, source_file, source_ext) in search_files:
                source_filename = os.path.splitext(file)[0]
                if target_filename == source_filename:
                    found_matching_source_file = True
            if not found_matching_source_file:
                unmatched_target_files.append((target_directory,
                                               target_file,
                                               target_ext))
        return unmatched_target_files

    unmatched_pyc_files = locate_unmatched_files(pyc_filenames, py_filenames)
    unmatched_pyo_files = locate_unmatched_files(pyo_filenames, py_filenames)

    if pyc_filenames or pyo_filenames:
        if unmatched_pyc_files or unmatched_pyo_files:
            for (directory, file, ext) in unmatched_pyc_files:
                reporter_output = ("A .pyc file was located without a matching"
                                   " source file."
                                   " File: {}").format(file)
                reporter.fail(reporter_output)
            for (directory, file, ext) in unmatched_pyo_files:
                reporter_output = ("A .pyo file was located without a matching"
                                   " source file."
                                   " File: {}").format(file)
                reporter.fail(reporter_output)
        else:
            pass  # No unmatched files found

    else:
        reporter_output = ("No .pyc or .pyo files found.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.17")
def check_for_generic_imports(app, reporter):
    """Check that all python imports are explicit. `from package import *` may
    run unneeded code.
    """
    all_python_files = list(app.iterate_files(types=[".py"]))

    import_patterns = ["from\s+.*\s+import\s+\*"]
    matches = app.search_for_patterns(import_patterns,
                                      types=[".py"])
    if len(all_python_files) > 0:
        for (fileref_output, match) in matches:
            filepath, line_number = fileref_output.rsplit(":", 1)
            reporter_output = ("A generic python import was detected. All"
                               " module imports must specify what is imported."
                               " File: {}"
                               " Line Number: {}").format(filepath, line_number)
            reporter.manual_check(reporter_output)
    else:
        reporter_output = ("No python files detected.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "security")
@splunk_appinspect.cert_version(min="1.1.17")
def check_built_in_import_function(app, reporter):
    """Check that the python `__import__` method is not used."""
    # This method shouldn't be used because it's "code smell" in that if you're
    # dynamically loading libraries via strings there is some concern
    # https://docs.python.org/2/library/functions.html#__import__
    # Nice SO dicussion on this here:
    # http://stackoverflow.com/questions/28231738/import-vs-import-vs-importlib-import-module
    # http://stackoverflow.com/questions/2724260/why-does-pythons-import-require-fromlist
    all_python_files = list(app.iterate_files(types=[".py"]))

    import_patterns = ["__import__"]
    matches = app.search_for_patterns(import_patterns,
                                      types=[".py"])
    if len(all_python_files) > 0:
        for (fileref_output, match) in matches:
            filepath, line_number = fileref_output.rsplit(":", 1)
            reporter_output = ("The __import__ function was detected being"
                               " used. Please use the `import` keyword instead."
                               " File: {}"
                               " Line Number: {}").format(filepath, line_number)
            reporter.manual_check(reporter_output)
    else:
        reporter_output = ("No python files detected.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "appapproval", "manual")
@splunk_appinspect.cert_version(min="1.0.0")
def check_for_hard_coded_paths(app, reporter):
    """Check that Python scripts use OS-safe paths (NOT Windows-specific
    or *nix-specific paths). Whenever possible use os.path.
    """
    python_source_files = [file
                           for directory, file, ext
                           in app.iterate_files(types=['.py'])]
    if len(python_source_files) > 0:
        reporter_output = ("Files will be reviewed during code review.")
        reporter.manual_check(reporter_output)
