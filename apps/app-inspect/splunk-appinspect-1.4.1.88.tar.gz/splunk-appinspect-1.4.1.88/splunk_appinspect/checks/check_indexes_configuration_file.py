# Copyright 2016 Splunk Inc. All rights reserved.

"""
### Indexes.conf File Standards

Ensure that the index configuration file located in the `default` folder are
well formed and valid.

- [indexes.conf](http://docs.splunk.com/Documentation/Splunk/latest/Admin/Indexesconf)
"""

# Python Standard Library
import logging
# Custom Libraries
import splunk_appinspect

report_display_order = 2
logger = logging.getLogger(__name__)


@splunk_appinspect.cert_version(min="1.1.23")
@splunk_appinspect.tags("splunk_appinspect")
def check_indexes_conf_does_not_exist(app, reporter):
    """Check that the app does not create indexes."""
    if app.file_exists("default", "indexes.conf"):
        reporter_output = ("Apps and add-ons should not create indexes. Indexes"
                           " should only be defined by Splunk System"
                           " Administrators to meet the data storage and"
                           " retention needs of the installation. Consider"
                           " using Tags or Source Types to identify data"
                           " instead index location.")
        reporter.fail(reporter_output)


@splunk_appinspect.cert_version(min="1.1.7")
@splunk_appinspect.tags("splunk_appinspect", "cloud")
def check_validate_default_indexes_not_modified(app, reporter):
    """Check that no default Splunk indexes are modified by the app."""
    default_indexes = ["_audit", "_internal", "_introspection" "_thefishbucket",
                       "history", "main", "provider-family:hadoop",
                       "splunklogger", "summary", "volume:_splunk_summaries"]
    if app.file_exists("default", "indexes.conf"):
        indexes_config = app.get_config("indexes.conf")
        for section in indexes_config.section_names():
            if section in default_indexes:
                reporter_output = ("The following index was modified: {}"
                                   ).format(section)
                reporter.fail(reporter_output)
    else:
        reporter_output = "No `default/indexes.conf`file exists"
        reporter.not_applicable(reporter_output)
