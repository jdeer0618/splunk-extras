# Copyright 2016 Splunk Inc. All rights reserved.

"""
### Deprecated features from Splunk 6.3.

These features should not be supported in Splunk 6.3 and onward

- [List of deprecated features](http://docs.splunk.com/Documentation/Splunk/6.3.5/ReleaseNotes/Deprecatedfeatures#Previously_deprecated_features_that_still_work).
- [Version changes](https://docs.splunk.com/Documentation/Splunk/6.3.5/Installation/ChangesforSplunkappdevelopers).
"""

# Python Standard Libraries
import logging
import re
# Third-Party Libraries
import bs4
# Custom Libraries
import splunk_appinspect

logger = logging.getLogger(__name__)


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_3", "deprecated_feature")
@splunk_appinspect.cert_version(min="1.1.11")
def check_for_simple_xml_seed_element(app, reporter):
    # Warning: This may give false positives on account that it checks EVERY
    # xml file, and there may be a possibility that someone may want to use
    # the <seed> element in a totally different context. That said this isn't
    # likely to cause problems in the future.
    """Check for the deprecated `<seed>` option in Simple XML forms.
    Use the `<initialValue>` element instead.
    """

    xml_files = list(app.get_filepaths_of_files(types=[".xml"]))
    #  Outputs not_applicable if no xml files found
    if not xml_files:
        reporter_output = "No xml files found."
        reporter.not_applicable(reporter_output)

    # Performs the checks
    for relative_filepath, full_filepath in xml_files:
        soup = bs4.BeautifulSoup(open(full_filepath), "lxml-xml")
        seed_elements = soup.find_all("seed")
        if seed_elements:
            reporter_output = ("<seed> element detected in:"
                               " file: {}").format(relative_filepath)
            reporter.fail(reporter_output)
        else:
            pass  # Do nothing, everything is fine


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_3", "deprecated_feature")
@splunk_appinspect.cert_version(min="1.1.11")
def check_for_simple_xml_searchTemplate_element(app, reporter):
    # Warning: This may give false positives on account that it checks EVERY
    # xml file, and there may be a possibility that someone may want to use
    # the <searchTemplate> element in a totally different context. That said this isn't
    # likely to cause problems in the future.
    """Check for the deprecated `<searchTemplate>` element in Simple XML files.
    Use the `<search>` element instead.
    """

    xml_files = list(app.get_filepaths_of_files(basedir="default",
                                                types=[".xml"]))
    #  Outputs not_applicable if no xml files found
    if not xml_files:
        reporter_output = "No xml files found."
        reporter.not_applicable(reporter_output)

    # Performs the checks
    for relative_filepath, full_filepath in xml_files:
        soup = bs4.BeautifulSoup(open(full_filepath), "lxml-xml")
        searchTemplate = soup.find_all("searchTemplate")
        if searchTemplate:
            reporter_output = ("<searchTemplate> detected in"
                               " file: {}").format(relative_filepath)
            reporter.fail(reporter_output)
        else:
            pass  # Do nothing, everything is fine


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_3", "deprecated_feature")
@splunk_appinspect.cert_version(min="1.1.11")
def check_for_simple_xml_option_element_with_name_previewResults(app, reporter):
    # Warning: This may give false positives on account that it checks EVERY
    # xml file, and there may be a possibility that someone may want to use
    # the <option name="previewResults"> element in a totally different context.
    # That said this isn't likely to cause problems in the future.
    """Check for the deprecated `<option name='previewResults'>` in Simple XML 
    files.
    """

    xml_files = list(app.get_filepaths_of_files(basedir="default",
                                                types=[".xml"]))
    #  Outputs not_applicable if no xml files found
    if not xml_files:
        reporter_output = "No xml files found."
        reporter.not_applicable(reporter_output)

    # Performs the checks
    for relative_filepath, full_filepath in xml_files:
        soup = bs4.BeautifulSoup(open(full_filepath), "lxml-xml")
        option_elements = soup.find_all("option", {"name": "previewResults"})
        if option_elements:
            reporter_output = ("<option name='previewResults'> detected in"
                               " file: {}").format(relative_filepath)
            reporter.fail(reporter_output)
        else:
            pass  # Do nothing, everything is fine


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_3", "deprecated_feature")
@splunk_appinspect.cert_version(min="1.1.11")
def check_for_simple_xml_chart_element_with_deprecated_option_names(app, reporter):
    # Warning: This may give false positives on account that it checks EVERY
    # xml file. That said this isn't likely to cause problems in the future.
    """Check for Simple XML `<chart>` panels with deprecated options
    `charting.axisLabelsY.majorTickSize` or
    `charting.axisLabelsY.majorLabelVisibility`.
    """
    attributes = ["charting.axisLabelsY.majorLabelVisibility",
                  "charting.axisLabelsY.majorTickSize"]
    attribute_regex_string = "|".join(attributes)
    attribute_regex = re.compile(attribute_regex_string)
    xml_files = list(app.get_filepaths_of_files(basedir="default",
                                                types=[".xml"]))
    attributes_logging_string = ", ".join(attributes)

    #  Outputs not_applicable if no xml files found
    if not xml_files:
        reporter_output = "No xml files found."
        reporter.not_applicable(reporter_output)

    # Performs the checks
    for relative_filepath, full_filepath in xml_files:
        soup = bs4.BeautifulSoup(open(full_filepath), "lxml-xml")
        # Get all chart elements
        chart_elements = list(soup.find_all("chart"))
        for chart_element in chart_elements:
            # Gets all child option elements of said charts, and filters out to
            # only the ones that have a name attribute with the deprecated
            # values
            option_elements = chart_element.find_all("option",
                                                     {"name": attribute_regex})
            if option_elements:
                reporter_output = ("A <chart> was detected with deprecated "
                                   "options in "
                                   "file: {}").format(relative_filepath)
                reporter.fail(reporter_output)
            else:
                pass  # Do nothing, everything is fine


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_3", "deprecated_feature", "advanced_xml")
@splunk_appinspect.cert_version(min="1.1.11")
def check_for_advanced_xml_module_elements(app, reporter):
    """Check for Advanced XML `<module>` elements."""
    # Checks to see if any advanced xml file exists, using the existence of
    # `<module>` elements as a hueristic. This only applies to xml files in
    # default/data/ui/views.

    direcory_to_search = "default/data/ui/views"
    xml_files = list(app.get_filepaths_of_files(basedir=direcory_to_search,
                                                types=[".xml"]))

    #  Outputs not_applicable if no xml files found
    if not xml_files:
        reporter_output = "No xml files found."
        reporter.not_applicable(reporter_output)

    # Performs the checks
    for relative_filepath, full_filepath in xml_files:
        soup = bs4.BeautifulSoup(open(full_filepath), "lxml-xml")
        # Get all module elements
        module_elements = list(soup.find_all("module"))
        for module_element in module_elements:
            reporter_output = ("<module> element found in"
                               " file: {}").format(relative_filepath)
            reporter.fail(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_3", "deprecated_feature", "advanced_xml")
@splunk_appinspect.cert_version(min="1.1.11")
def check_for_advanced_xml_appserver_modules_directory(app, reporter):
    """Check for Advanced XML `appserver/modules` directory."""
    # Checks to see if an appserver/modules directory exists. This is used as
    # a hueristic to determine if advanced xml being used.
    if app.directory_exists("appserver", "modules"):
        reporter_output = ("The Advanced XML `appserver/modules` directory was "
                           " detected. Please replace Advanced XMl with Simple "
                           " XML.")
        reporter.fail(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_3", "deprecated_feature", "advanced_xml")
@splunk_appinspect.cert_version(min="1.1.11")
def check_for_advanced_xml_view_element(app, reporter):
    """Check for Advanced XML `<view>` elements that do not have the
    `redirect` or `html` types.
    """
    # Per Siegfried Puchbauer
    # If it's a <view> element then it's a view XML. This can either be
    #   - A system view/page if the type attribute is html (ie. <view type="html">)
    #   - A redirect (not a view at all) if the type attribute is redirect (ie. <view type="redirect">)
    #   - Otherwise it's Advanced XML

    # Tried to make a sweet negative look ahead regex, but it wasn't working
    # Now you get a boring regex
    attributes = ["html", "redirect"]
    attribute_regex_string = "|".join(attributes)
    attribute_regex = re.compile(attribute_regex_string)

    # excludes default/data/ui/nav - #WARNING excludes any nav folder...
    excluded_directories = ["nav"]

    # Gets ALL xml files
    xml_files = list(app.get_filepaths_of_files(excluded_dirs=excluded_directories,
                                                types=[".xml"]))

    #  Outputs not_applicable if no xml files found
    if not xml_files:
        reporter_output = "No xml files found."
        reporter.not_applicable(reporter_output)

    # Performs the checks
    for relative_filepath, full_filepath in xml_files:
        soup = bs4.BeautifulSoup(open(full_filepath), "lxml-xml")

        all_view_elements = list(soup.find_all("view"))
        non_advanced_xml_view_elements = list(soup.find_all("view",
                                                            {"type": attribute_regex}))
        total_view_element_count = len(all_view_elements)
        non_advanced_xml_view_count = len(non_advanced_xml_view_elements)
        advanced_xml_view_count = total_view_element_count - non_advanced_xml_view_count

        if advanced_xml_view_count > 0:
            reporter_output = ("An XML file was detected that contains Advanced"
                               " XML <view> types."
                               " File: {}").format(relative_filepath)
            reporter.fail(reporter_output)
        else:
            pass  # Do nothing, everything is fine


@splunk_appinspect.tags("splunk_appinspect", "splunk_6_3", "deprecated_feature", "django_bindings")
@splunk_appinspect.cert_version(min="1.1.11")
def check_for_django_bindings(app, reporter):
    """Check for use of Django bindings."""
    # Checks to see that the django directory exist. If it does, then
    # django bindings are being used.
    if app.directory_exists("django"):
        reporter_output = ("The `django` directory was detected.")
        reporter.fail(reporter_output)
    else:
        pass  # Do nothing, everything is fine
