# Copyright 2016 Splunk Inc. All rights reserved.

"""
### Platform targets and claimed supported Splunk versions
"""

# Claimed Platform Targets: App must run against claimed supported Splunk
# versions.
# Python Standard Libraries
import logging
# Custom Libraries
import splunk_appinspect

report_display_order = 6
logger = logging.getLogger(__name__)


@splunk_appinspect.tags('splunk_appinspect', 'manual', 'appapproval')
@splunk_appinspect.cert_version(min='1.0.0')
def check_install_on_claimed_targets(app, reporter):
    """Check that the app installs on all claimed target platforms."""
    reporter.manual_check("App will be checked during code review.")
