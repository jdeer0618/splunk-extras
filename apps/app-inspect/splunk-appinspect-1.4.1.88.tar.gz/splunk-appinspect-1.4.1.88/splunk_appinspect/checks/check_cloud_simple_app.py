# Copyright 2016 Splunk Inc. All rights reserved.

"""
### Cloud Operations Simple Application Check

This group serves to help validate simple applications in an effort to try and
automate the cloud operations validation process.
"""

# Python Standard Libraries
import logging
import os
import platform
import re
import subprocess
# Third-Party Libraries
import bs4
# Custom Libraries
import splunk_appinspect


logger = logging.getLogger(__name__)


# ------------------------------------------------------------------------------
# White List Checks Go Here
# ------------------------------------------------------------------------------
@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_default_directory_file_white_list(app, reporter):
    """Check for files in `default/` that cannot be automatically approved for Splunk Cloud."""
    allowed_files = [
        "app.conf",
        "authorize.conf",                    # checked in check_authorize_conf_admin_all_objects_privileges
        "inputs.conf",                       # checked in check_only_encrypted_inputs_are_used
        "indexes.conf",                      # checked in check_indexes_conf_only_uses_splunk_db_variable
        "savedsearches.conf",                # checked in check_for_real_time_saved_searches
        "workflow_actions.conf",             # checked in check_workflow_actions_link_uri_are_https
        "setup.xml",                         # safe
        "fields.conf",                       # safe
        "collections.conf",                  # safe
        "eventgen.conf", "eventtypes.conf",  # safe
        "macros.conf",                       # safe
        "props.conf",                        # safe
        "searchbnf.conf",                    # safe
        "tags.conf",                         # safe
        "transforms.conf",                   # safe
        "ui-prefs.conf",                     # safe
        "viewstates.conf",                   # safe
        "visualizations.conf",               # safe
        "readme.txt"                         # safe
    ]
    allowed_directories = [
        # checked in check_default_data_ui_alerts_directory_file_white_list
        os.path.join("default", "data", "ui", "alerts", ""),
        # checked in check_default_data_ui_html_directory_file_white_list
        os.path.join("default", "data", "ui", "html", ""),
        # checked in check_default_data_ui_manager_directory_file_white_list
        os.path.join("default", "data", "ui", "manager", ""),
        # checked in check_default_data_ui_nav_directory_file_white_list
        os.path.join("default", "data", "ui", "nav", ""),
        # checked in check_default_data_ui_panels_directory_file_white_list
        os.path.join("default", "data", "ui", "panels", ""),
        # checked in check_default_data_ui_quickstart_directory_file_white_list
        os.path.join("default", "data", "ui", "quickstart", ""),
        # checked in check_default_data_ui_views_directory_file_white_list
        os.path.join("default", "data", "ui", "views", "")
    ]
    if app.directory_exists("default"):
        for directory, filename, ext in app.iterate_files(basedir="default"):
            if directory not in allowed_directories:
                file_path = os.path.join(directory, filename)
                if filename not in allowed_files:
                    reporter_output = ("Please investigate this file: {}"
                                       ).format(file_path)
                    reporter.manual_check(reporter_output)
    else:
        reporter_output = "The `default` directory does not exist."

        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_default_data_ui_views_directory_file_white_list(app, reporter):
    """Check that `default/data/ui/views` contains only allowed files."""
    allowed_file_types = [".html", ".xml"]
    allowed_filenames = ["README"]
    if app.directory_exists("default", "data", "ui", "views"):
        for directory, filename, ext in app.iterate_files(basedir="default/data/ui/views"):
            if(ext not in allowed_file_types and
               filename not in allowed_filenames):
                reporter_output = ("Please investigate this file: {}"
                                   ).format(filename)
                reporter.manual_check(reporter_output)
    else:
        reporter_output = ("The `default/data/ui/views` directory does not"
                           " exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_default_data_ui_panels_directory_file_white_list(app, reporter):
    """Check that `default/data/ui/panels` contains only .xml or .html files."""
    allowed_file_types = [".html", ".xml"]
    if app.directory_exists("default", "data", "ui", "panels"):
        for directory, filename, ext in app.iterate_files(basedir="default/data/ui/panels"):
            if ext not in allowed_file_types:
                reporter_output = ("Please investigate this file: {}"
                                   ).format(filename)
                reporter.manual_check(reporter_output)
    else:
        reporter_output = ("The `default/data/ui/panels` directory does not"
                           " exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_default_data_ui_nav_file_white_list(app, reporter):
    """Check that `default/data/ui/nav` contains only .xml or .html files."""
    allowed_file_types = [".html", ".xml"]
    if app.directory_exists("default", "data", "ui", "nav"):
        for directory, filename, ext in app.iterate_files(basedir="default/data/ui/nav"):
            if ext not in allowed_file_types:
                reporter_output = ("Please investigate this file: {}"
                                   ).format(filename)
                reporter.manual_check(reporter_output)
    else:
        reporter_output = ("The `default/data/ui/nav` directory does not"
                           " exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_default_data_ui_html_file_white_list(app, reporter):
    """Check that `default/data/ui/html` contains only .xml or .html files."""
    allowed_file_types = [".html", ".xml"]
    if app.directory_exists("default", "data", "ui", "html"):
        for directory, filename, ext in app.iterate_files(basedir="default/data/ui/html"):
            if ext not in allowed_file_types:
                reporter_output = ("Please investigate this file: {}"
                                   ).format(filename)
                reporter.manual_check(reporter_output)
    else:
        reporter_output = ("The `default/data/ui/html` directory does not"
                           " exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_default_data_ui_alerts_file_white_list(app, reporter):
    """Check that `default/data/ui/alerts` contains only .xml or .html files."""
    allowed_file_types = [".html", ".xml"]
    if app.directory_exists("default", "data", "ui", "alerts"):
        for directory, filename, ext in app.iterate_files(basedir="default/data/ui/alerts"):
            if ext not in allowed_file_types:
                reporter_output = ("Please investigate this file: {}"
                                   ).format(filename)
                reporter.manual_check(reporter_output)
    else:
        reporter_output = ("The `default/data/ui/alerts` directory does not"
                           " exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_default_data_ui_quickstart_file_white_list(app, reporter):
    """Check that `default/data/ui/quickstart` contains only .xml or .html
    files.
    """
    allowed_file_types = [".html", ".xml"]
    if app.directory_exists("default", "data", "ui", "quickstart"):
        for directory, filename, ext in app.iterate_files(basedir="default/data/ui/quickstart"):
            if ext not in allowed_file_types:
                reporter_output = ("Please investigate this file: {}"
                                   ).format(filename)
                reporter.manual_check(reporter_output)
    else:
        reporter_output = ("The `default/data/ui/quickstart` directory does not"
                           " exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_default_data_ui_manager_file_white_list(app, reporter):
    """Check `default/data/ui/manager` for any files that configure modular
    inputs, communicate unencrypted data, or store plain text credentials.
    """
    allowed_file_types = []
    if app.directory_exists("default", "data", "ui", "manager"):
        for directory, filename, ext in app.iterate_files(basedir="default/data/ui/manager"):
            if ext not in allowed_file_types:
                reporter_output = ("Please investigate this file to ensure that"
                                   " it does not configure modular inputs,"
                                   " communicate unencrypted data, or store"
                                   " plain text credentials: {}"
                                  ).format(filename)
                reporter.manual_check(reporter_output)
    else:
        reporter_output = ("The `default/data/ui/manager` directory does not"
                           " exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_lookups_white_list(app, reporter):
    """
    Check that `lookups/` contains only approved file types
     (.csv, .csv.default, .csv.gz, .csv.tgz, .kmz).
    """
    allowed_file_types = [".csv", ".csv.default", ".csv.gz", ".csv.tgz", ".kmz"]
    if app.directory_exists("lookups"):
        for directory, filename, ext in app.iterate_files(basedir="lookups"):
            # if ext not in allowed_file_types:
            # Pretty messy way to determine if the allowed extension is a dotted
            # file, on account that iterate files will only return the last
            # level of the extension I.E. .csv.gz returns .gz instead of
            # .csv.gz
            does_file_name_end_with_extension = len([True
                                                     for allowed_file_type
                                                     in allowed_file_types
                                                     if filename.endswith(allowed_file_type)]) > 0
            if not does_file_name_end_with_extension:
                reporter_output = ("Please investigate this file: {}"
                                   ).format(filename)
                reporter.manual_check(reporter_output)
    else:
        reporter_output = ("The `lookups` directory does not exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "splunk_appinspect")
@splunk_appinspect.cert_version(min="1.1.19")
def check_metadata_white_list(app, reporter):
    """Check that the `metadata/` directory only contains .meta files."""
    allowed_file_types = [".meta"]
    if app.directory_exists("metadata"):
        for directory, filename, ext in app.iterate_files(basedir="metadata"):
            if ext not in allowed_file_types:
                reporter_output = ("File within the `metadata` directory found"
                                   " with an extension other than `.meta`."
                                   " Please remove this file: {}"
                                  ).format(filename)
                reporter.fail(reporter_output)
    else:
        reporter_output = ("The `metadata` directory does not exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_root_directory_file_white_list(app, reporter):
    """Check that root directory contains only files with the following
    extensions '.md', '.pdf', '.rst', or '.txt', '.rtf', '.doc', '.docx',
        or filename is 'README'.
    """
    allowed_file_types = [".md", ".pdf", ".rst", ".txt", ".rtf", ".doc", ".docx"]
    allowed_filenames = ["README"]
    for directory, filename, ext in app.iterate_files(recurse_depth=0):
        if ext not in allowed_file_types and filename not in allowed_filenames:
            reporter_output = ("Please investigate this file: {}"
                               ).format(filename)
            reporter.manual_check(reporter_output)


@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_static_directory_file_white_list(app, reporter):
    """Check that the `static/` directory contains only known file types."""
    allowed_file_types = [".css", ".csv",
                          ".eot",
                          ".gif",
                          ".htm", ".html",
                          ".ico",
                          ".jpeg", ".jpg",
                          ".kmz",
                          ".less",
                          ".map", ".md",
                          ".otf",
                          ".pdf", ".png",
                          ".rst",
                          ".sass", ".scss", ".svg",
                          ".ttf", ".txt",
                          ".woff", ".woff2",
                          ".xhtml", ".xml"]
    if app.directory_exists("static"):
        for directory, filename, ext in app.iterate_files(basedir="static"):
            if ext not in allowed_file_types:
                reporter_output = ("Please investigate this file: {}"
                                   ).format(filename)
                reporter.manual_check(reporter_output)
    else:
        reporter_output = ("The `static` directory does not exist.")
        reporter.not_applicable(reporter_output)


# ------------------------------------------------------------------------------
# Grey List Checks Go Here
# ------------------------------------------------------------------------------
# -------------------
# authorize.conf
# -------------------
@splunk_appinspect.tags("splunk_appinspect", "cloud")
@splunk_appinspect.cert_version(min="1.1.20")
def check_authorize_conf_admin_all_objects_privileges(app, reporter):
    """Check that authorize.conf does not grant excessive administrative
    permissions to the user.
    """
    if app.file_exists("default", "authorize.conf"):
        authorize_conf_file = app.authorize_conf()
        properties_to_validate = ["admin_all_objects",
                                  "change_authentication",
                                  "importRoles"]
        import_roles_to_prevent = {"admin", "sc_admin"}
        for section in authorize_conf_file.sections():
            # Ignore capability stanzas
            if section.name.startswith("capability::"):
                continue
            for property_to_validate in properties_to_validate:
                if not section.has_option(property_to_validate):
                    continue
                value = section.get_option(property_to_validate).value
                if property_to_validate == "importRoles":
                    # Check importRoles for inheriting of blacklisted roles
                    # using set intersection of importRoles & blacklisted roles
                    bad_roles = set(value.split(";")) & import_roles_to_prevent
                    for bad_role in bad_roles:
                        reporter_output = ("authorize.conf [{}] attempts to"
                                           " inherit from the `{}` role."
                                           ).format(section.name, bad_role)
                        reporter.fail(reporter_output)
                elif value == "enabled":
                    reporter_output = ("authorize.conf [{}] contains `{} ="
                                       " enabled`").format(section.name,
                                       property_to_validate)
                    reporter.fail(reporter_output)
    else:
        reporter_output = ("authorize.conf does not exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.20")
def check_alert_actions_conf_does_not_have_command_property(app, reporter):
    """Check that custom alert actions do not use the command property."""
    if app.file_exists("default", "alert_actions.conf"):
        alert_actions = app.get_alert_actions()
        for alert_action in alert_actions.get_alert_actions():
            if alert_action.has_command():
                reporter_output = ("Alert action [{}] has a command specified."
                                   ).format(alert_action.name)
                reporter.manual_check(reporter_output)
    else:
        reporter_output = ("alert_actions.conf does not exist.")
        reporter.not_applicable(reporter_output)


# -------------------
# authentication.conf
# -------------------
@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.20")
def check_authentication_conf_does_not_have_sslKeysfilePassword_property(app, reporter):
    """Check that stanzas in authentication.conf do not use the
    sslKeysfilePassword property.
    """
    if app.file_exists("default", "authentication.conf"):
        authentication_conf_file = app.authentication_conf()
        stanzas_with_ssl_keys_file_password = [stanza_name
                                               for stanza_name
                                               in authentication_conf_file.section_names()
                                               if authentication_conf_file.has_option(stanza_name, "sslKeysfilePassword")]
        if stanzas_with_ssl_keys_file_password:
            for stanza_name in stanzas_with_ssl_keys_file_password:
                reporter_output = ("authentication.conf [{}] contains the"
                                   " property sslKeysfilePassword."
                                   ).format(stanza_name)
                reporter.fail(reporter_output)
    else:
        reporter_output = ("authentication.conf does not exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.20")
def check_authentication_conf_does_not_have_bindDNPassword_property(app, reporter):
    """Check that stanzas in `authentication.conf` do not use the the
    bindDNpassword property.
    """
    if app.file_exists("default", "authentication.conf"):
        authentication_conf_file = app.authentication_conf()
        stanzas_with_bindDNpassword = [stanza_name
                                       for stanza_name
                                       in authentication_conf_file.section_names()
                                       if authentication_conf_file.has_option(stanza_name, "bindDNpassword")]
        if stanzas_with_bindDNpassword:
            for stanza_name in stanzas_with_bindDNpassword:
                reporter_output = ("authentication.conf [{}] contains the"
                                   " property bindDNpassword."
                                   ).format(stanza_name)
                reporter.fail(reporter_output)
    else:
        reporter_output = ("authentication.conf does not exist.")
        reporter.not_applicable(reporter_output)


# -------------------
# indexes.conf
# -------------------
@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.20")
def check_indexes_conf_only_uses_splunk_db_variable(app, reporter):
    """Check that indexes defined in `indexes.conf` use relative paths starting
    with $SPLUNK_DB.
    """
    properties_to_validate = ["bloomHomePath",
                              "coldPath",
                              "homePath",
                              "summaryHomePath",
                              "thawedPath", "tstatsHomePath"]
    path_pattern_string = "^\$SPLUNK_DB"
    if app.file_exists("default", "indexes.conf"):
        indexes_conf_file = app.indexes_conf()

        not_using_splunk_db_matches = [(section.name, property_key)
                                       for section
                                       in indexes_conf_file.sections()
                                       for property_key, property_value
                                       in section.items()
                                       if(property_key in properties_to_validate and
                                          re.search(path_pattern_string, property_value) is None)]

        for stanza_name, property_matched in not_using_splunk_db_matches:
            reporter_output = ("The stanza [{}] has the property {}, that is"
                               " using a path that does not contain $SPLUNK_DB."
                               " Please make sure that only $SPLUNK_DB is used."
                               ).format(stanza_name, property_matched)
            reporter.fail(reporter_output)

    else:
        reporter_output = ("indexes.conf does not exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.20")
def check_for_index_volume_usage(app, reporter):
    """Check that `indexes.conf` does not declare volumes."""
    path_pattern_string = "^volume:"
    if app.file_exists("default", "indexes.conf"):
        indexes_conf_file = app.indexes_conf()

        volume_stanza_names = [section.name
                               for section
                               in indexes_conf_file.sections()
                               if re.search(path_pattern_string, section.name)]
        for stanza_name in volume_stanza_names:
            reporter_output = ("The stanza [{}] was declared as volume."
                               ).format(stanza_name)
            reporter.fail(reporter_output)

    else:
        reporter_output = ("indexes.conf does not exist.")
        reporter.not_applicable(reporter_output)


# -------------------
# inputs.conf
# -------------------
@splunk_appinspect.tags("cloud", "inputs_conf")
@splunk_appinspect.cert_version(min="1.2.1")
def check_for_appropriate_inputs_monitor_stanza(app, reporter):
    """Check that apps only monitor their own directory
    `$SPLUNK_HOME/etc/apps/<app-dir>/*`.
    """
    if app.file_exists("default", "inputs.conf"):
        splunk_home_path = "$SPLUNK_HOME"
        splunk_apps_path = os.path.join(splunk_home_path, "etc", "apps")

        app_path = os.path.join(splunk_apps_path, app.name)

        inputs_configuration_file = app.inputs_conf()

        monitor_stanzas = [stanza_name
                           for stanza_name in inputs_configuration_file.section_names()
                           if re.search("^monitor:\/\/", stanza_name)]
        incorrect_monitor_stanzas = [monitor_stanza
                                     for monitor_stanza in monitor_stanzas
                                     if not monitor_stanza.startswith("monitor://{}".format(app_path))]

        for incorrect_monitor_stanza in incorrect_monitor_stanzas:
            reporter_output = ("default/inputs.conf contains a [monitor://]"
                               " stanza that is monitoring more than allowed."
                               " Please remove this functionality."
                               " Stanza: [{}]"
                               " App path: {}"
                               ).format(incorrect_monitor_stanza,
                                        app_path)
            reporter.fail(reporter_output)
    else:
        reporter.not_applicable("The default/inputs.conf does not exist.")


@splunk_appinspect.tags("cloud", "inputs_conf")
@splunk_appinspect.cert_version(min="1.2.1")
def check_for_splunk_var_log_monitoring(app, reporter):
    """Check that apps do not monitor the `$SPLUNK_HOME/var/log/*` directory."""
    if app.file_exists("default", "inputs.conf"):
        splunk_home_path = "$SPLUNK_HOME"
        splunk_log_path = os.path.join(splunk_home_path, "var", "log")

        inputs_configuration_file = app.inputs_conf()

        monitor_stanzas = [stanza_name
                           for stanza_name in inputs_configuration_file.section_names()
                           if re.search("^monitor:\/\/", stanza_name)]
        incorrect_monitor_stanzas = [monitor_stanza
                                     for monitor_stanza in monitor_stanzas
                                     if monitor_stanza.startswith("monitor://{}".format(splunk_log_path))]

        for incorrect_monitor_stanza in incorrect_monitor_stanzas:
            reporter_output = ("Apps should not monitor $SPLUNK_HOME/var/log/*"
                               " as Splunk already ensures files in this folder"
                               " are are monitored."
                               ).format(incorrect_monitor_stanza)
            reporter.warn(reporter_output)
    else:
        reporter.not_applicable("The default/inputs.conf does not exist.")


@splunk_appinspect.tags("splunk_appinspect", "cloud", "manual", "inputs_conf")
@splunk_appinspect.cert_version(min="1.2.1")
def check_inputs_monitor_for_parent_path(app, reporter):
    """Checks that the [monitor] stanza does not use `..` in any part of its
    path.
    """
    if app.file_exists("default", "inputs.conf"):
        inputs_configuration_file = app.inputs_conf()

        monitor_stanzas = [stanza_name
                           for stanza_name in inputs_configuration_file.section_names()
                           if stanza_name.startswith("monitor")]

        incorrect_monitor_stanzas = [stanza_name
                                     for stanza_name in monitor_stanzas
                                     if (".." in stanza_name.split("/") or
                                         ".." in stanza_name.split("\\"))]

        for incorrect_monitor_stanza in incorrect_monitor_stanzas:
            reporter_output = ("default/inputs.conf contains a [monitor://]"
                               " stanza that is using relative paths for a"
                               " parent directory. This is not allowed."
                               " Stanza: [{}]").format(incorrect_monitor_stanza)
            reporter.fail(reporter_output)
    else:
        reporter.not_applicable("The default/inputs.conf does not exist.")


@splunk_appinspect.tags("cloud", "inputs_conf")
@splunk_appinspect.cert_version(min="1.2.1")
def check_for_inputs_fifo_usage(app, reporter):
    """Check [fifo] stanza is not used in `inputs.conf`."""
    if app.file_exists("default", "inputs.conf"):
        inputs_configuration_file = app.inputs_conf()

        fifo_stanzas = [stanza_name
                        for stanza_name in inputs_configuration_file.section_names()
                        if re.search("^fifo:\/\/", stanza_name)]

        for fifo_stanza in fifo_stanzas:
            reporter_output = ("default/inputs.conf contains a [fifo://]"
                               " stanza that is not allowed."
                               " Please remove this functionality."
                               " Stanza: [{}]").format(fifo_stanza)
            reporter.manual_check(reporter_output)
    else:
        reporter.not_applicable("The default/inputs.conf does not exist.")


@splunk_appinspect.tags("splunk_appinspect", "cloud", "manual", "inputs_conf")
@splunk_appinspect.cert_version(min="1.2.1")
def check_inputs_fifo_for_parent_path(app, reporter):
    """Checks that the [fifo] stanza does not use `..` in any part of its
    path.
    """
    if app.file_exists("default", "inputs.conf"):
        inputs_configuration_file = app.inputs_conf()
        fifo_stanzas = [stanza_name
                        for stanza_name in inputs_configuration_file.section_names()
                        if stanza_name.startswith("fifo")]

        incorrect_fifo_stanzas = [stanza_name
                                  for stanza_name in fifo_stanzas
                                  if (".." in stanza_name.split("/") or
                                      ".." in stanza_name.split("\\"))]

        for incorrect_fifo_stanza in incorrect_fifo_stanzas:
            reporter_output = ("default/inputs.conf contains a [monitor://]"
                               " stanza that is using relative paths for a"
                               " parent directory. This is not allowed."
                               " Stanza: [{}]").format(incorrect_fifo_stanza)
            reporter.fail(reporter_output)
    else:
        reporter.not_applicable("The default/inputs.conf does not exist.")


@splunk_appinspect.tags("cloud")
@splunk_appinspect.cert_version(min="1.2.1")
def check_inputs_conf_for_tcp(app, reporter):
    """Check that `default/inputs.conf` does not contain a `tcp` stanza."""
    if app.file_exists("default", "inputs.conf"):
        inputs_conf = app.inputs_conf()
        for section in inputs_conf.section_names():
            if section.startswith("tcp://"):
                reporter_output = ("The `default/inputs.conf` specifies `tcp`"
                                   " this is prohibited in Splunk Cloud. An alternative is to"
                                   " use `tcp-ssl`. Stanza [{}]".format(section))
                reporter.fail(reporter_output)
    else:
        reporter_output = ("`default/inputs.conf` does not exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud")
@splunk_appinspect.cert_version(min="1.2.1")
def check_inputs_conf_for_splunk_tcp(app, reporter):
    """Check that `default/inputs.conf` does not contain a `splunktcp`
    stanza.
    """
    if app.file_exists("default", "inputs.conf"):
        inputs_conf = app.inputs_conf()
        for section in inputs_conf.section_names():
            if re.search("^splunktcp(?!-ssl)", section):
                reporter_output = ("The `default/inputs.conf` specifies"
                                   " `splunktcp` this is prohibited in Splunk"
                                   " Cloud. An alternative is to use"
                                   " `splunktcp-ssl`. Stanza: [{}]"
                                   ).format(section)
                reporter.fail(reporter_output)
    else:
        reporter_output = ("`default/inputs.conf` does not exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud")
@splunk_appinspect.cert_version(min="1.2.1")
def check_inputs_conf_for_fschange(app, reporter):
    """Check that `default/inputs.conf` does not contain a `fschange`
    stanza.
    """
    if app.file_exists("default", "inputs.conf"):
        inputs_conf = app.inputs_conf()
        for section in inputs_conf.section_names():
            if section.startswith("fschange"):
                reporter_output = ("The `default/inputs.conf` specifies"
                                   " `fschange` this is prohibited in Splunk"
                                   " Cloud. Stanza: [{}]").format(section)
                reporter.fail(reporter_output)
    else:
        reporter_output = ("`default/inputs.conf` does not exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "inputs_conf")
@splunk_appinspect.cert_version(min="1.2.1")
def check_inputs_conf_for_global_settings(app, reporter):
    """Check that `default/inputs.conf` does not use any global settings."""
    # Global settings should be grouped under the "default" stanza for the
    # ConfigurationFile object that this library uses
    if app.file_exists("default", "inputs.conf"):
        global_stanza_name = "default"
        inputs_conf = app.inputs_conf()
        if inputs_conf.has_section(global_stanza_name):
            for option_name, option_value in inputs_conf.get_section(global_stanza_name).items():
                reporter_output = ("The `default/inputs.conf` specifies"
                                   " global settings. These are prohibited in"
                                   " Splunk Cloud instances. Please remove this"
                                   " functionality."
                                   " Property: {} = {}"
                                   ).format(option_name, option_value)
                reporter.fail(reporter_output)
    else:
        reporter_output = ("`default/inputs.conf` does not exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "inputs_conf")
@splunk_appinspect.cert_version(min="1.2.1")
def check_inputs_conf_for_http_global_usage(app, reporter):
    """Check that `default/inputs.conf` does not contain a `[http]`
    stanza.
    """
    if app.file_exists("default", "inputs.conf"):
        inputs_conf = app.inputs_conf()
        for section in inputs_conf.section_names():
            if section == "http":
                reporter_output = ("The `default/inputs.conf` specifies a"
                                   " global `[http]` stanza. This is prohibited"
                                   " in Splunk Cloud instances. Please change"
                                   " this functionality to target local"
                                   " settings by using [http://] instead."
                                   " Stanza: [{}]"
                                   ).format(section)
                reporter.fail(reporter_output)
    else:
        reporter_output = ("`default/inputs.conf` does not exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud")
@splunk_appinspect.cert_version(min="1.2.1")
def check_inputs_conf_for_splunktcptoken(app, reporter):
    """Check that `default/inputs.conf` does not contain a `splunktcptoken`
    stanza.
    """
    if app.file_exists("default", "inputs.conf"):
        inputs_conf = app.inputs_conf()
        for section in inputs_conf.section_names():
            if section.startswith("splunktcptoken"):
                reporter_output = ("The `default/inputs.conf` specifies"
                                   " `splunktcptoken` this is prohibited in"
                                   " Splunk Cloud. Stanza: {}").format(section)
                reporter.fail(reporter_output)
    else:
        reporter_output = ("`default/inputs.conf` does not exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud")
@splunk_appinspect.cert_version(min="1.2.1")
def check_inputs_conf_for_batch(app, reporter):
    """Check that `default/inputs.conf` does not contain a `batch` stanza."""

    def in_app_home(a, sect):
        _, path = sect.split("batch://", 1)
        if not path:
            return False
        # uses absolute path to app home to validate
        win_path = "$SPLUNK_HOME\\etc\\apps\\{}".format(a.name)
        unix_path = "$SPLUNK_HOME/etc/apps/{}".format(a.name)
        return path.startswith(win_path) or path.startswith(unix_path)

    if app.file_exists("default", "inputs.conf"):
        inputs_conf = app.inputs_conf()
        for section in inputs_conf.section_names():
            if section.startswith("batch") and not in_app_home(app, section):
                reporter_output = ("The `default/inputs.conf` specifies `batch`"
                                   " this is prohibited in Splunk Cloud."
                                   " Stanza: [{}]").format(section)
                reporter.fail(reporter_output)
    else:
        reporter_output = ("`default/inputs.conf` does not exist.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud", "splunk_appinspect")
@splunk_appinspect.cert_version(min="1.2.1")
def check_inputs_conf_for_udp(app, reporter):
    """Check that inputs.conf does not have any UDP inputs."""
    if app.file_exists("default", "inputs.conf"):
        inputs_conf = app.inputs_conf()
        for section in inputs_conf.section_names():
            if section.startswith("udp"):
                reporter_output = ("The `default/inputs.conf` specifies `udp`"
                                   " this is prohibited in Splunk Cloud."
                                   " Stanza: [{}]").format(section)
                reporter.fail(reporter_output)
    else:
        reporter_output = ("`default/inputs.conf` does not exist.")
        reporter.not_applicable(reporter_output)


# -------------------
# setup.xml
# -------------------
@splunk_appinspect.tags("cloud")
@splunk_appinspect.cert_version(min="1.1.20")
def check_setup_xml_for_incorrect_password_rest_endpoint(app, reporter):
    """Check that all passwords configured in setup.xml are stored in the
    storage/passwords endpoint. (Documentation)[http://docs.splunk.com/Documentation/Splunk/6.4.2/AdvancedDev/SetupExampleCredentials]
    """
    if app.file_exists("default", "setup.xml"):
        full_filepath = app.get_filename("default", "setup.xml")
        soup = bs4.BeautifulSoup(open(full_filepath), "lxml-xml")
        block_elements_with_passwords = [block_element
                                         for block_element
                                         in soup.find_all("block")
                                         for input_element
                                         in block_element.find_all("input", {"field": "password"})]
        for block_element in block_elements_with_passwords:
            block_title = block_element.get("title", "<Block Title Not Found>")
            if block_element.has_attr("endpoint"):
                endpoint = block_element["endpoint"].lower().strip()
                if endpoint == "storage/passwords":
                    pass  # Success - This block element is pointing to storage/passwords and contains a type element of password
                else:
                    # not storage/passwords, could be a custom endpoint
                    reporter_output = ("Block `{}` contains a password which is"
                                       " stored in the `{}` endpoint. Please"
                                       " use the `storage/passwords` endpoint."
                                       ).format(block_title, endpoint)
                    reporter.manual_check(reporter_output)
            else:
                # No endpoint
                reporter_output = ("No endpoint specified for block `{}`."
                                   ).format(block_title)
                reporter.fail(reporter_output)
    else:
        reporter_output = ("`default/setup.xml` does not exist.")
        reporter.not_applicable(reporter_output)


# -------------------
# transforms.conf
# -------------------
@splunk_appinspect.tags("cloud", "manual")
@splunk_appinspect.cert_version(min="1.1.20")
def check_transforms_conf_for_external_cmd(app, reporter):
    """Check that `transforms.conf` does not contain any transforms with an
    `external_cmd=<string>` attribute.
    """
    if app.file_exists("default", "transforms.conf"):
        transforms_conf = app.transforms_conf()
        external_command_stanzas = [section
                                    for section
                                    in transforms_conf.sections()
                                    if section.has_option("external_cmd")]
        for external_command_stanza in external_command_stanzas:
            reporter_output = ("The `transforms.conf` stanza [{}] is"
                               " using the `external_cmd` property. Please"
                               " investigate."
                               ).format(external_command_stanza.name)
            reporter.manual_check(reporter_output)
    else:
        reporter_output = ("`default/transforms.conf` does not exist.")
        reporter.not_applicable(reporter_output)


# ------------------------------------------------------------------------------
# Manual Checks Go Here
# ------------------------------------------------------------------------------
@splunk_appinspect.tags("splunk_appinspect", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_for_monitoring_of_splunk_cloud_infrastructure(app, reporter):
    """Check that the app does not monitor Splunk Cloud infrastructure."""
    reporter_output = ("Please check for monitoring of Splunk Cloud"
                       " infrastructure.")
    reporter.manual_check(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_for_lookup_tables_prefilled_with_customer_data(app, reporter):
    """Check for pre-filled lookup tables."""
    if(app.directory_exists("lookups") and
            os.listdir(app.get_filename("lookups"))):
        reporter_output = ("Please check for Lookup tables pre-filled with customer"
                           " data.")
        reporter.manual_check(reporter_output)
    else:
        reporter.not_applicable("The lookups/ directory does not exist.")


@splunk_appinspect.tags("splunk_appinspect", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_for_unencrypted_network_communications(app, reporter):
    """Check that all network communications are encrypted."""
    reporter_output = ("Please check for inbound or outbound unencrypted network communications."
                       "All communications with Splunk Cloud must be encrypted.")
    reporter.manual_check(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_for_udp_network_communications(app, reporter):
    """Check for UDP network communication."""
    reporter_output = ("Please check for inbound or outbound UDP network communications."
                       "UDP network communication is prohibited in Splunk Cloud for security.")
    reporter.manual_check(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_for_communication_with_third_party_services(app, reporter):
    """Check if the app is sending data to 3rd party services."""
    reporter_output = ("Please check if the app is sending data to third-party"
                       " services.")
    reporter.manual_check(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_for_required_access_to_private_infrastructure(app, reporter):
    """Check if the app requires access to private infrastructure."""
    reporter_output = ("Please check for required access to private"
                       " infrastructure.")
    reporter.manual_check(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "manual", "cloud")
@splunk_appinspect.cert_version(min="1.1.19")
def check_for_binary_files_without_source_code(app, reporter):
    """Check that all executable binary files have matching source code."""
    if platform.system() == "Windows":
        reporter.manual_check("Matching source check will be done manually during code review.")
    else:
        # excluding docx, python and egg files to reduce false positives, and covered elsewhere
        exclude_types = [".docx", ".egg", ".py"]

        app_files_iterator = app.iterate_files(excluded_types=exclude_types)
        for directory, file, extension in app_files_iterator:
            current_file_relative_path = os.path.join(directory, file)
            current_file_full_path = app.get_filename(current_file_relative_path)

            file_output = subprocess.check_output(["file", "-b", current_file_full_path])
            file_output_regex = re.compile("(.)*executable(.)*|(.)*shared object(.)*|(.)*binary(.)*|(.)*archive(.)*",
                                           re.DOTALL | re.IGNORECASE | re.MULTILINE)
            if re.match(file_output_regex, file_output):
                reporter_output = ("Please check that any binary files that exist have"
                                   " accompanying source code."
                                   " File: {}  Format: {}").format(current_file_relative_path, file_output)
                reporter.manual_check(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_for_reverse_shells(app, reporter):
    """Check that the app does not contain reverse shells."""
    reporter_output = ("Please check for reverse shells.")
    reporter.manual_check(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_for_auto_update_features(app, reporter):
    """Check that the app does not implement auto-update features."""
    bin_directories = [bin_directory
                       for arch in app.arch_bin_dirs
                       for bin_directory in app.arch_bin_dirs[arch]]
    app_has_auto_update_capability = False
    for bin_directory in bin_directories:
        bin_directory_iterator = app.iterate_files(basedir=bin_directory)
        for directory, file, extension in bin_directory_iterator:
            app_has_auto_update_capability = True
            reporter_output = ("Please check the {} directory for app"
                               " auto-update features.").format(directory)
            reporter.manual_check(reporter_output)
            break
    # If an app has nothing in the /bin directory and nothing in any of
    # the architecture-specific directories, it does not have the capacity to
    # update itself.
    if not app_has_auto_update_capability:
        reporter_output = ("No scripts found in /bin or architecture-specific"
                           " directories in app.")
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("splunk_appinspect", "manual")
@splunk_appinspect.cert_version(min="1.1.19")
def check_for_known_vulnerabilities_in_third_party_libraries(app, reporter):
    """Check third party libraries for known vulnerabilities."""
    reporter_output = ("Please check for known vulnerabilities in third-party"
                       " libraries. Use these links:"
                       " https://web.nvd.nist.gov/view/vuln/search."
                       " and https://nvd.nist.gov/cvss.cfm")
    reporter.manual_check(reporter_output)


@splunk_appinspect.tags("cloud")
@splunk_appinspect.cert_version(min="1.1.22")
def check_for_perl(app, reporter):
    """Check if the app contains Perl scripts. Perl scripts will be inspected 
    for compliance with Splunk Cloud security policy."""
    application_files = list(app.iterate_files(types=[".cgi", ".pl", ".pm"]))
    if application_files:
        for directory, file, ext in application_files:
            current_file_relative_path = os.path.join(directory, file)
            reporter_output = ("File: {}").format(current_file_relative_path)
            reporter.manual_check(reporter_output)

    else:
        reporter_output = "No Perl scripts found in app."
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags('cloud')
@splunk_appinspect.cert_version(min='1.1.22')
def check_for_javascript(app, reporter):
    """Check if the app contains Javascript files. Javascript scripts will be 
    inspected for compliance with Splunk Cloud security policy."""
    application_files = list(app.iterate_files(types=[".coffee", ".js", ".js.map"]))
    if application_files:
        for directory, file, ext in application_files:
            current_file_relative_path = os.path.join(directory, file)
            reporter_output = ("Javascript file found."
                               " File: {}").format(current_file_relative_path)
            reporter.manual_check(reporter_output)
    else:
        reporter_output = "No Javascript files found in app."
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags('cloud')
@splunk_appinspect.cert_version(min='1.1.22')
def check_for_java(app, reporter):
    """Check if the app contains java files.
    Java files will be inspected for compliance with Splunk Cloud security  policy."""
    application_files = list(app.iterate_files(types=[".class", ".jar", ".java"]))
    if application_files:
        for directory, file, ext in application_files:
            current_file_relative_path = os.path.join(directory, file)
            reporter_output = ("java file found."
                               " File: {}").format(current_file_relative_path)
            reporter.manual_check(reporter_output)
    else:
        reporter_output = "No java files found in app."
        reporter.not_applicable(reporter_output)


@splunk_appinspect.tags("cloud")
@splunk_appinspect.cert_version(min='1.1.22')
def check_for_local(app, reporter):
    """Check that local settings do not violate Splunk Cloud security policies."""
    # TODO: Automation skips local. Remove this check when local/*.conf files are checked automatically.
    #       are checked automatically.
    if app.directory_exists("local"):
        local_directory_path = os.path.join(app.app_dir, "local")
        local_directory_contents = os.listdir(local_directory_path)
        if local_directory_contents:
            reporter_output = "A `local` directory exists in the app."
            reporter.manual_check(reporter_output)
        else:
            # Git doesn't let empty directories be commited so the test package
            # for this logic cannot be committed, therefore this has only been
            # verified locally on a dev machine
            reporter_output = "The `local` directory exists, but it empty."
            reporter.warn(reporter_output)
    else:
        reporter_output = "The `local` directory was not found."
        reporter.not_applicable(reporter_output)
