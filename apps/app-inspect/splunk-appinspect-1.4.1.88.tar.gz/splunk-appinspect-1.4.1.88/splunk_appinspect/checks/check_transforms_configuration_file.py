# Copyright 2016 Splunk Inc. All rights reserved.

"""
### Transforms.conf File Standards

Ensure that the transforms.conf file located in the `default` folder is well
formed and valid.

- [transforms.conf](http://docs.splunk.com/Documentation/Splunk/latest/Admin/Transformsconf)
"""

# Python Standard Library
import logging
# Custom Libraries
import splunk_appinspect

report_display_order = 2
logger = logging.getLogger(__name__)


@splunk_appinspect.tags("splunk_appinspect")
@splunk_appinspect.cert_version(min="1.1.12")
def check_all_lookups_are_used(app, reporter):
    """All files in the /lookups directory should be referenced in
    `transforms.conf`.
    """
    lookup_file_names = set()
    transforms_reference_file_names = set()
    for dir, file, ext in app.iterate_files(basedir="lookups"):
        if file.endswith(".default"):
            loookup_file_no_default_suffix = file[:len(file) - len(".default")]
            lookup_file_names.add(loookup_file_no_default_suffix)
        else:
            lookup_file_names.add(file)

    if app.file_exists("default", "transforms.conf"):
        transforms = app.transforms_conf()
        for section in transforms.sections():
            if section.has_option("filename"):
                lookup_file_name = section.get_option("filename").value
                transforms_reference_file_names.add(lookup_file_name)
        for file in (lookup_file_names - transforms_reference_file_names):
            reporter_output = ("Lookup file {} is not referenced in"
                               " transforms.conf").format(file)
            reporter.fail(reporter_output)
    else:
        reporter.not_applicable("No transforms.conf in app")


@splunk_appinspect.tags("splunk_appinspect")
@splunk_appinspect.cert_version(min="1.1.12")
def check_capture_groups_in_transforms(app, reporter):
    """Check that all capture groups are used in transforms.conf.
    Groups not used for capturing should use the
    [non-capture group syntax](http://docs.splunk.com/Documentation/Splunk/latest/Knowledge/AboutSplunkregularexpressions#Non-capturing_group_matching)
    """
    if app.file_exists("default", "transforms.conf"):
        transforms = app.transforms_conf()
        for section in transforms.sections():
            if section.has_option("REGEX") and section.has_option("FORMAT"):
                regex = section.get_option("REGEX").value
                fmt = section.get_option("FORMAT").value
                lparens = 0
                rparens = 0
                noncapture_groups = 0
                for i in range(len(regex)):
                    # Skip \( as it"s a literal paren, not a group start
                    if regex[i] == "(" and (i == 0 or regex[i - 1] != "\\"):
                        lparens += 1
                        if regex[i + 1] == ":" or regex[i + 1] == "?":
                            noncapture_groups += 1
                    if regex[i] == ")" and (i == 0 or regex[i - 1] != "\\"):
                        rparens += 1
                if lparens != rparens:
                    reporter_output = ("Parentheses do not match in [{}] stanza of"
                                       " transforms.conf").format(section.name)
                    reporter.fail(reporter_output)
                    return
                unused_groups = []
                for i in range(lparens - noncapture_groups):
                    if fmt.find("$" + str(i + 1)) < 0:
                        unused_groups.append("$" + str(i + 1))

                if len(unused_groups) > 0:
                    reporter_output = ("The format option in [{}] stanza of"
                                       " transforms.conf did not include {}"
                                       ).format(section.name, ", ".join(unused_groups))
                    reporter.fail(reporter_output)
    else:
        reporter.not_applicable("No transforms.conf in app")
