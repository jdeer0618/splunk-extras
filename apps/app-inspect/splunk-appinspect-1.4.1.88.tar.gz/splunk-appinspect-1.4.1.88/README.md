# Splunk AppInspect
## Overview

AppInspect is a tool for assessing a Splunk App's compliance with Splunk recommended development practices, by using static analysis. AppInspect is open for extension, allowing other teams to compose checks that meet their domain specific needs for semi- or fully-automated analysis and validation of Splunk Apps. 

# Documentation

You can find the documentation for Splunk AppInspect at http://dev.splunk.com/goto/appinspectdocs

# Builds

| Branch     | Status    | 
| --------|---------|
| master  | [![Build Status](http://re-jenkins03.sv.splunk.com:8080/buildStatus/icon?job=AppInspect_Toolkit/CLI_package_from_master)](http://re-jenkins03.sv.splunk.com:8080/job/AppInspect_Toolkit/job/CLI_package_from_master/)   | 
| dev | [![Build Status](http://re-jenkins03.sv.splunk.com:8080/buildStatus/icon?job=AppInspect_Toolkit/CLI_package_from_dev)](http://re-jenkins03.sv.splunk.com:8080/job/AppInspect_Toolkit/job/CLI_package_from_dev/) | 


# Copyright

Copyright 2016 Splunk Inc. All rights reserved.
